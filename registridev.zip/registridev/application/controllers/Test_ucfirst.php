<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Test_ucfirst extends CMS_Controller{
    function index(){
        $this->view('test_ucfirst_index');
    }
}