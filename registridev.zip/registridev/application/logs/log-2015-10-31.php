<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-10-31 22:48:27 --> Unable to connect to the database
