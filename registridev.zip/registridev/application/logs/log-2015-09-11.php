<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-09-11 00:00:02 --> Severity: Notice --> Undefined variable: partitionTitles /var/www/html/registridev/modules/mara2/views/mara2_step1a.php 160
ERROR - 2015-09-11 00:00:02 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/registridev/modules/mara2/views/mara2_step1a.php 160
ERROR - 2015-09-11 00:01:33 --> Severity: Notice --> Undefined variable: partitionTitles /var/www/html/registridev/modules/mara2/views/mara2_step1a.php 160
ERROR - 2015-09-11 00:01:33 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/registridev/modules/mara2/views/mara2_step1a.php 160
ERROR - 2015-09-11 00:02:46 --> Severity: Notice --> Undefined variable: data /var/www/html/registridev/modules/mara2/views/mara2_step1a.php 95
ERROR - 2015-09-11 00:02:46 --> Severity: Notice --> Undefined variable: partitionTitles /var/www/html/registridev/modules/mara2/views/mara2_step1a.php 160
ERROR - 2015-09-11 00:02:46 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/registridev/modules/mara2/views/mara2_step1a.php 160
ERROR - 2015-09-11 00:03:13 --> Severity: Notice --> Undefined variable: partitionTitles /var/www/html/registridev/modules/mara2/views/mara2_step1a.php 160
ERROR - 2015-09-11 00:03:13 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/registridev/modules/mara2/views/mara2_step1a.php 160
ERROR - 2015-09-11 00:03:53 --> Severity: Notice --> Undefined variable: partitionTitles /var/www/html/registridev/modules/mara2/views/mara2_step1a.php 160
ERROR - 2015-09-11 00:03:53 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/registridev/modules/mara2/views/mara2_step1a.php 160
ERROR - 2015-09-11 00:04:21 --> Severity: Notice --> Undefined variable: partition /var/www/html/registridev/modules/mara2/views/mara2_step1a.php 95
ERROR - 2015-09-11 00:04:21 --> Severity: Notice --> Undefined variable: partitionTitles /var/www/html/registridev/modules/mara2/views/mara2_step1a.php 160
ERROR - 2015-09-11 00:04:21 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/registridev/modules/mara2/views/mara2_step1a.php 160
ERROR - 2015-09-11 00:04:31 --> Severity: Notice --> Undefined variable: partitionTitles /var/www/html/registridev/modules/mara2/views/mara2_step1a.php 160
ERROR - 2015-09-11 00:04:31 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/registridev/modules/mara2/views/mara2_step1a.php 160
ERROR - 2015-09-11 00:04:43 --> Severity: Notice --> Undefined variable: partitionTitles /var/www/html/registridev/modules/mara2/views/mara2_step1a.php 160
ERROR - 2015-09-11 00:04:43 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/registridev/modules/mara2/views/mara2_step1a.php 160
ERROR - 2015-09-11 00:22:04 --> Severity: Notice --> Undefined variable: path /var/www/html/registridev/modules/mara2/controllers/mara2.php 760
ERROR - 2015-09-11 00:22:04 --> Severity: Notice --> Undefined variable: path /var/www/html/registridev/modules/mara2/controllers/mara2.php 760
ERROR - 2015-09-11 00:22:04 --> Severity: Notice --> Undefined variable: path /var/www/html/registridev/modules/mara2/controllers/mara2.php 760
ERROR - 2015-09-11 00:22:04 --> Severity: Notice --> Undefined variable: path /var/www/html/registridev/modules/mara2/controllers/mara2.php 760
ERROR - 2015-09-11 00:22:04 --> Severity: Notice --> Undefined variable: path /var/www/html/registridev/modules/mara2/controllers/mara2.php 760
ERROR - 2015-09-11 00:22:04 --> Severity: Notice --> Undefined variable: path /var/www/html/registridev/modules/mara2/controllers/mara2.php 760
ERROR - 2015-09-11 00:22:04 --> Severity: Notice --> Undefined variable: path /var/www/html/registridev/modules/mara2/controllers/mara2.php 760
ERROR - 2015-09-11 00:22:04 --> Severity: Notice --> Undefined variable: path /var/www/html/registridev/modules/mara2/controllers/mara2.php 760
ERROR - 2015-09-11 00:22:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/libraries/Session/drivers/Session_cookie.php 734
ERROR - 2015-09-11 00:24:17 --> Severity: Error --> Call to undefined function int() /var/www/html/registridev/modules/mara2/controllers/mara2.php 762
ERROR - 2015-09-11 00:25:24 --> Severity: Notice --> Undefined variable: xmlpath /var/www/html/registridev/modules/mara2/controllers/mara2.php 755
ERROR - 2015-09-11 00:25:24 --> Severity: Warning --> scandir(): Directory name cannot be empty /var/www/html/registridev/modules/mara2/controllers/mara2.php 755
ERROR - 2015-09-11 00:25:24 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/registridev/modules/mara2/controllers/mara2.php 757
ERROR - 2015-09-11 00:36:08 --> Severity: Parsing Error --> syntax error, unexpected ''unparsed'' (T_CONSTANT_ENCAPSED_STRING), expecting ')' /var/www/html/registridev/modules/mara2/controllers/mara2.php 780
ERROR - 2015-09-11 00:46:37 --> Severity: Notice --> Undefined variable: disabled /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 38
ERROR - 2015-09-11 00:46:37 --> Severity: Notice --> Undefined variable: disabled /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 38
ERROR - 2015-09-11 00:46:37 --> Severity: Notice --> Undefined variable: disabled /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 38
ERROR - 2015-09-11 00:46:37 --> Severity: Notice --> Undefined variable: disabled /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 38
ERROR - 2015-09-11 00:46:37 --> Severity: Notice --> Undefined variable: disabled /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 38
ERROR - 2015-09-11 00:50:15 --> Severity: Notice --> Undefined index: RA04 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:50:15 --> Severity: Notice --> Undefined index: RA05 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:50:15 --> Severity: Notice --> Undefined index: RA06 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:50:15 --> Severity: Notice --> Undefined index: RA07 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:51:18 --> Severity: Notice --> Undefined index: RA04 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:51:18 --> Severity: Notice --> Undefined index: RA05 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:51:18 --> Severity: Notice --> Undefined index: RA06 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:51:18 --> Severity: Notice --> Undefined index: RA07 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:52:29 --> Severity: Notice --> Undefined index: RA04 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:52:29 --> Severity: Notice --> Undefined index: RA05 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:52:29 --> Severity: Notice --> Undefined index: RA06 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:52:29 --> Severity: Notice --> Undefined index: RA07 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:52:29 --> Severity: Notice --> Undefined index: RA11 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:53:04 --> Severity: Notice --> Undefined index: RA04 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:53:04 --> Severity: Notice --> Undefined index: RA05 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:53:04 --> Severity: Notice --> Undefined index: RA06 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:53:04 --> Severity: Notice --> Undefined index: RA07 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:53:04 --> Severity: Notice --> Undefined index: RA11 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:54:02 --> Severity: Notice --> Undefined index: RA04 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:54:02 --> Severity: Notice --> Undefined index: RA05 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:54:02 --> Severity: Notice --> Undefined index: RA06 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:54:02 --> Severity: Notice --> Undefined index: RA07 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:54:02 --> Severity: Notice --> Undefined index: RA11 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:54:09 --> Severity: Notice --> Undefined index: RA04 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:54:09 --> Severity: Notice --> Undefined index: RA05 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:54:09 --> Severity: Notice --> Undefined index: RA06 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:54:09 --> Severity: Notice --> Undefined index: RA07 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:54:09 --> Severity: Notice --> Undefined index: RA11 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 00:55:07 --> Severity: Parsing Error --> syntax error, unexpected ';', expecting ')' /var/www/html/registridev/modules/mara2/controllers/mara2.php 781
ERROR - 2015-09-11 00:55:20 --> Severity: Notice --> Undefined index: RA04 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:55:20 --> Severity: Notice --> Undefined index: RA05 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:55:20 --> Severity: Notice --> Undefined index: RA06 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:55:20 --> Severity: Notice --> Undefined index: RA07 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:55:50 --> Severity: Notice --> Undefined index: RA04 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:55:50 --> Severity: Notice --> Undefined index: RA05 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:55:50 --> Severity: Notice --> Undefined index: RA06 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:55:50 --> Severity: Notice --> Undefined index: RA07 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:55:50 --> Severity: Notice --> Undefined index: RA11 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:56:07 --> Severity: Notice --> Undefined index: RA04 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:56:07 --> Severity: Notice --> Undefined index: RA05 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:56:07 --> Severity: Notice --> Undefined index: RA06 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:56:07 --> Severity: Notice --> Undefined index: RA07 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:56:07 --> Severity: Notice --> Undefined index: RA11 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:56:44 --> Severity: Notice --> Undefined index: RA04 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:56:44 --> Severity: Notice --> Undefined index: RA05 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:56:44 --> Severity: Notice --> Undefined index: RA06 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:56:44 --> Severity: Notice --> Undefined index: RA07 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:56:44 --> Severity: Notice --> Undefined index: RA11 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:57:44 --> Severity: Notice --> Undefined variable: xmlNumbres /var/www/html/registridev/modules/mara2/controllers/mara2.php 782
ERROR - 2015-09-11 00:57:44 --> Severity: Notice --> Undefined index: RA04 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:57:44 --> Severity: Notice --> Undefined index: RA05 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:57:44 --> Severity: Notice --> Undefined index: RA06 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:57:44 --> Severity: Notice --> Undefined index: RA07 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:57:44 --> Severity: Notice --> Undefined index: RA11 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:57:57 --> Severity: Notice --> Undefined index: RA04 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:57:57 --> Severity: Notice --> Undefined index: RA05 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:57:57 --> Severity: Notice --> Undefined index: RA06 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:57:57 --> Severity: Notice --> Undefined index: RA07 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:57:57 --> Severity: Notice --> Undefined index: RA11 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:58:58 --> Severity: Notice --> Undefined index: RA04 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:58:58 --> Severity: Notice --> Undefined index: RA05 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:58:58 --> Severity: Notice --> Undefined index: RA06 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:58:58 --> Severity: Notice --> Undefined index: RA07 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:59:47 --> Severity: Notice --> Undefined index: RA04 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:59:47 --> Severity: Notice --> Undefined index: RA05 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:59:47 --> Severity: Notice --> Undefined index: RA06 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 00:59:47 --> Severity: Notice --> Undefined index: RA07 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 01:00:59 --> Severity: Notice --> Undefined index: RA04 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 01:00:59 --> Severity: Notice --> Undefined index: RA05 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 01:00:59 --> Severity: Notice --> Undefined index: RA06 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 01:00:59 --> Severity: Notice --> Undefined index: RA07 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 01:00:59 --> Severity: Notice --> Undefined index: RA11 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 01:03:22 --> Severity: Notice --> Undefined index: RA04 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 50
ERROR - 2015-09-11 01:03:22 --> Severity: Notice --> Undefined index: RA05 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 50
ERROR - 2015-09-11 01:03:22 --> Severity: Notice --> Undefined index: RA06 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 50
ERROR - 2015-09-11 01:03:22 --> Severity: Notice --> Undefined index: RA07 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 50
ERROR - 2015-09-11 01:03:22 --> Severity: Notice --> Undefined index: RA11 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 50
ERROR - 2015-09-11 01:04:33 --> Severity: Notice --> Undefined index: RA04 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 56
ERROR - 2015-09-11 01:04:33 --> Severity: Notice --> Undefined index: RA05 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 56
ERROR - 2015-09-11 01:04:33 --> Severity: Notice --> Undefined index: RA06 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 56
ERROR - 2015-09-11 01:04:33 --> Severity: Notice --> Undefined index: RA07 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 56
ERROR - 2015-09-11 01:04:33 --> Severity: Notice --> Undefined index: RA11 /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 56
ERROR - 2015-09-11 01:17:23 --> Severity: Parsing Error --> syntax error, unexpected '{' /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 41
ERROR - 2015-09-11 01:22:52 --> Severity: Parsing Error --> syntax error, unexpected '">validazione</a>"' (T_CONSTANT_ENCAPSED_STRING), expecting ',' or ';' /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 01:23:28 --> Severity: Error --> Call to undefined method MY_Loader::cms_module_path() /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 42
ERROR - 2015-09-11 10:58:10 --> Severity: Notice --> Undefined variable: regId /var/www/html/registridev/modules/mara2/views/mara2_step3a.php 43
ERROR - 2015-09-11 11:01:00 --> Severity: Parsing Error --> syntax error, unexpected '=', expecting ')' /var/www/html/registridev/modules/mara2/controllers/mara2.php 784
ERROR - 2015-09-11 11:02:02 --> Severity: Notice --> Undefined variable: regName /var/www/html/registridev/modules/mara2/controllers/mara2.php 784
ERROR - 2015-09-11 11:13:16 --> Severity: Notice --> Undefined variable: attributes /var/www/html/registridev/modules/mara2/views/mara2_step3b.php 70
ERROR - 2015-09-11 11:13:16 --> Severity: Notice --> Undefined variable: result /var/www/html/registridev/modules/mara2/views/mara2_step3b.php 71
ERROR - 2015-09-11 11:13:16 --> Severity: Notice --> Undefined variable: result /var/www/html/registridev/modules/mara2/views/mara2_step3b.php 72
ERROR - 2015-09-11 11:13:16 --> Severity: Notice --> Undefined variable: result /var/www/html/registridev/modules/mara2/views/mara2_step3b.php 73
ERROR - 2015-09-11 11:29:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/modules/mara2/controllers/mara2.php:801) /var/www/html/registridev/system/libraries/Session/drivers/Session_cookie.php 734
ERROR - 2015-09-11 11:44:17 --> Severity: Notice --> Undefined variable: zip_submit /var/www/html/registridev/modules/mara2/views/mara2_step3b.php 82
ERROR - 2015-09-11 11:56:45 --> Severity: Notice --> Undefined index: registro_id /var/www/html/registridev/modules/mara2/controllers/mara2.php 105
ERROR - 2015-09-11 11:56:45 --> Severity: Notice --> Undefined index: name /var/www/html/registridev/modules/mara2/controllers/mara2.php 106
ERROR - 2015-09-11 11:57:42 --> Severity: Notice --> Undefined index: registro_id /var/www/html/registridev/modules/mara2/controllers/mara2.php 105
ERROR - 2015-09-11 11:57:42 --> Severity: Notice --> Undefined index: name /var/www/html/registridev/modules/mara2/controllers/mara2.php 106
ERROR - 2015-09-11 12:52:03 --> Severity: Warning --> file_get_contents(mara_folders/06_toc/list.txt): failed to open stream: No such file or directory /var/www/html/registridev/modules/mara2/views/mara2_step3b.php 96
ERROR - 2015-09-11 12:52:46 --> Severity: Warning --> file_get_contents(mara_folders/06_toc/list.txt): failed to open stream: No such file or directory /var/www/html/registridev/modules/mara2/views/mara2_step3b.php 96
ERROR - 2015-09-11 12:54:00 --> Severity: Warning --> file_get_contents({{ SITE_URL }}mara_folders/06_toc/list.txt): failed to open stream: No such file or directory /var/www/html/registridev/modules/mara2/views/mara2_step3b.php 96
ERROR - 2015-09-11 12:54:20 --> 404 Page Not Found: 
ERROR - 2015-09-11 12:55:16 --> 404 Page Not Found: 
ERROR - 2015-09-11 12:55:19 --> 404 Page Not Found: 
ERROR - 2015-09-11 12:55:30 --> Severity: Warning --> file_get_contents({{ SITE_URL }}mara_folders/06_toc/list2.txt): failed to open stream: No such file or directory /var/www/html/registridev/modules/mara2/views/mara2_step3b.php 96
ERROR - 2015-09-11 14:09:39 --> Severity: Notice --> Undefined variable: Indexed /var/www/html/registridev/modules/mara2/views/mara2_step3b.php 112
ERROR - 2015-09-11 14:09:39 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/registridev/modules/mara2/views/mara2_step3b.php 112
