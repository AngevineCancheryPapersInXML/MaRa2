<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-09-16 09:56:37 --> Unable to connect to the database
