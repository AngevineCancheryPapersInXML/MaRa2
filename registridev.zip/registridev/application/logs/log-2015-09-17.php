<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-09-17 19:55:21 --> Severity: Notice --> Undefined variable: data /var/www/html/registridev/modules/mara2/controllers/mara2.php 1350
ERROR - 2015-09-17 19:57:47 --> Severity: Notice --> Undefined variable: data /var/www/html/registridev/modules/mara2/controllers/mara2.php 1350
ERROR - 2015-09-17 19:59:15 --> Severity: Notice --> Undefined variable: data /var/www/html/registridev/modules/mara2/controllers/mara2.php 1350
ERROR - 2015-09-17 19:59:48 --> Severity: Notice --> Undefined variable: data /var/www/html/registridev/modules/mara2/controllers/mara2.php 1350
ERROR - 2015-09-17 20:00:15 --> Severity: Notice --> Undefined variable: data /var/www/html/registridev/modules/mara2/controllers/mara2.php 1350
ERROR - 2015-09-17 20:01:04 --> Severity: Notice --> Undefined variable: data /var/www/html/registridev/modules/mara2/controllers/mara2.php 1350
ERROR - 2015-09-17 20:01:59 --> Severity: Notice --> Undefined variable: data /var/www/html/registridev/modules/mara2/controllers/mara2.php 1350
ERROR - 2015-09-17 20:03:08 --> Severity: Notice --> Undefined variable: data /var/www/html/registridev/modules/mara2/controllers/mara2.php 1350
ERROR - 2015-09-17 20:03:22 --> Severity: Notice --> Undefined variable: data /var/www/html/registridev/modules/mara2/controllers/mara2.php 1350
ERROR - 2015-09-17 23:09:34 --> Severity: Notice --> Undefined variable: partitions /var/www/html/registridev/modules/mara2/controllers/mara2.php 2036
ERROR - 2015-09-17 23:09:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/registridev/modules/mara2/controllers/mara2.php 320
ERROR - 2015-09-17 23:09:34 --> Severity: Notice --> Undefined variable: tocTitles /var/www/html/registridev/modules/mara2/controllers/mara2.php 334
ERROR - 2015-09-17 23:09:34 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/registridev/modules/mara2/controllers/mara2.php 334
