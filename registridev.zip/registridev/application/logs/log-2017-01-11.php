<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-01-11 17:23:16 --> 404 Page Not Found: mara2/mara2
ERROR - 2017-01-11 17:23:23 --> 404 Page Not Found: mara2/mara2
