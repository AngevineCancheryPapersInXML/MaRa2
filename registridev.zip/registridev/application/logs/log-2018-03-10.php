<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-10 13:39:48 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-10 13:39:49 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-10 13:40:39 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-10 13:41:29 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-10 13:42:19 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-10 13:43:09 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-10 13:43:59 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-10 13:44:49 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-10 13:47:19 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-10 13:48:09 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
