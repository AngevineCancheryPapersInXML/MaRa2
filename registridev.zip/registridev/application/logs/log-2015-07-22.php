<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-07-22 01:12:36 --> Unable to connect to the database
