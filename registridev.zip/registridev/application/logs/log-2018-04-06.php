<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-04-06 17:25:10 --> 404 Page Not Found: 
ERROR - 2018-04-06 17:25:40 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-04-06 17:26:06 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-04-06 17:26:14 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-04-06 17:27:53 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-04-06 17:32:21 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
