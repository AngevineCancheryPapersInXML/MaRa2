<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-01-27 18:23:09 --> Unable to connect to the database
