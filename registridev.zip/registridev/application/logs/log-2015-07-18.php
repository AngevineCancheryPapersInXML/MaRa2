<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-07-18 16:49:35 --> Severity: Notice --> Undefined index: regName /var/www/html/registridev/modules/mara2/controllers/mara2.php 351
ERROR - 2015-07-18 16:49:35 --> Severity: Notice --> Undefined variable: partitions /var/www/html/registridev/modules/mara2/controllers/mara2.php 1635
ERROR - 2015-07-18 16:49:35 --> Severity: Notice --> Undefined variable: newfc /var/www/html/registridev/modules/mara2/controllers/mara2.php 427
ERROR - 2015-07-18 16:49:35 --> Severity: Warning --> array_filter() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 427
ERROR - 2015-07-18 16:49:35 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/registridev/modules/mara2/controllers/mara2.php 428
ERROR - 2015-07-18 16:49:35 --> Severity: Notice --> Undefined variable: newfc2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 451
ERROR - 2015-07-18 16:49:35 --> Severity: Warning --> implode(): Invalid arguments passed /var/www/html/registridev/modules/mara2/controllers/mara2.php 451
ERROR - 2015-07-18 16:49:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/libraries/Session/drivers/Session_cookie.php 734
ERROR - 2015-07-18 16:49:35 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/html/registridev/modules/mara2/views/mara2_step1b.php 86
ERROR - 2015-07-18 17:21:07 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 816
ERROR - 2015-07-18 17:21:07 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 783
ERROR - 2015-07-18 17:21:07 --> Severity: Notice --> Undefined offset: 9 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 651
ERROR - 2015-07-18 17:21:07 --> Severity: Notice --> Undefined offset: 10 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 651
ERROR - 2015-07-18 17:21:07 --> Severity: Notice --> Undefined offset: 11 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 651
ERROR - 2015-07-18 17:21:07 --> Severity: Notice --> Undefined offset: 12 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 651
ERROR - 2015-07-18 17:21:07 --> Severity: Notice --> Undefined offset: 13 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 651
ERROR - 2015-07-18 17:21:07 --> Severity: Notice --> Undefined offset: 14 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 651
ERROR - 2015-07-18 17:21:07 --> Severity: Notice --> Undefined offset: 15 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 651
ERROR - 2015-07-18 17:36:28 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 816
ERROR - 2015-07-18 17:36:28 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 783
ERROR - 2015-07-18 17:36:28 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1742
ERROR - 2015-07-18 17:36:28 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1742
ERROR - 2015-07-18 17:36:28 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1742
ERROR - 2015-07-18 17:36:28 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1742
ERROR - 2015-07-18 17:36:28 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1742
ERROR - 2015-07-18 17:36:28 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1742
ERROR - 2015-07-18 17:36:28 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1742
ERROR - 2015-07-18 17:36:28 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1742
ERROR - 2015-07-18 17:36:28 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1742
ERROR - 2015-07-18 17:36:28 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:36:28 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:36:28 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:36:28 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:36:28 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 959
ERROR - 2015-07-18 17:36:28 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 959
ERROR - 2015-07-18 17:36:28 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 960
ERROR - 2015-07-18 17:36:28 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 961
ERROR - 2015-07-18 17:39:05 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 816
ERROR - 2015-07-18 17:39:05 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 783
ERROR - 2015-07-18 17:39:05 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:39:05 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:39:05 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:39:05 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:39:05 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:39:05 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:39:05 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:39:05 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:39:05 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:39:05 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:39:05 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:39:05 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:39:05 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:39:05 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 959
ERROR - 2015-07-18 17:39:05 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 959
ERROR - 2015-07-18 17:39:05 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 960
ERROR - 2015-07-18 17:39:05 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 961
ERROR - 2015-07-18 17:39:33 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 816
ERROR - 2015-07-18 17:39:33 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 783
ERROR - 2015-07-18 17:39:33 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:39:33 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:39:33 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:39:33 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:39:33 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:39:33 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:39:33 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:39:33 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:39:33 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:39:33 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:39:33 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:39:33 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:39:33 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:39:33 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 959
ERROR - 2015-07-18 17:39:33 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 959
ERROR - 2015-07-18 17:39:33 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 960
ERROR - 2015-07-18 17:39:33 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 961
ERROR - 2015-07-18 17:41:23 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 816
ERROR - 2015-07-18 17:41:23 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 783
ERROR - 2015-07-18 17:41:23 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:41:23 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:41:23 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:41:23 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:41:23 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:41:23 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:41:23 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:41:23 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:41:23 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:41:23 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:41:23 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:41:23 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:41:23 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:41:23 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 959
ERROR - 2015-07-18 17:41:23 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 959
ERROR - 2015-07-18 17:41:23 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 960
ERROR - 2015-07-18 17:41:23 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 961
ERROR - 2015-07-18 17:43:06 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 816
ERROR - 2015-07-18 17:43:06 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 783
ERROR - 2015-07-18 17:43:06 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:43:06 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:43:06 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:43:06 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:43:06 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:43:06 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:43:06 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:43:06 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:43:06 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:43:06 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:43:06 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:43:06 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:43:06 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:43:06 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 959
ERROR - 2015-07-18 17:43:06 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 959
ERROR - 2015-07-18 17:43:06 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 960
ERROR - 2015-07-18 17:43:06 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 961
ERROR - 2015-07-18 17:44:34 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 816
ERROR - 2015-07-18 17:44:34 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 783
ERROR - 2015-07-18 17:44:34 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:44:34 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:44:34 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:44:34 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:44:34 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:44:34 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:44:34 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:44:34 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:44:34 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:44:34 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:44:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:44:34 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:44:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:44:34 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 959
ERROR - 2015-07-18 17:44:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 959
ERROR - 2015-07-18 17:44:34 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 960
ERROR - 2015-07-18 17:44:34 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 961
ERROR - 2015-07-18 17:45:26 --> Severity: Notice --> Undefined variable: fcontents2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 183
ERROR - 2015-07-18 17:45:26 --> Severity: Notice --> Undefined variable: fcontents2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 183
ERROR - 2015-07-18 17:45:26 --> Severity: Notice --> Undefined variable: fcontents2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 183
ERROR - 2015-07-18 17:45:26 --> Severity: Notice --> Undefined variable: fcontents2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 183
ERROR - 2015-07-18 17:45:26 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 817
ERROR - 2015-07-18 17:45:26 --> Severity: Notice --> Undefined variable: fcontents2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 183
ERROR - 2015-07-18 17:45:26 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 784
ERROR - 2015-07-18 17:45:26 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:45:26 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:45:26 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:45:26 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:45:26 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:45:26 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:45:26 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:45:26 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:45:26 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:45:26 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:45:26 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:45:26 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:45:26 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:45:26 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 960
ERROR - 2015-07-18 17:45:26 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 960
ERROR - 2015-07-18 17:45:26 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 961
ERROR - 2015-07-18 17:45:26 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 17:45:41 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 817
ERROR - 2015-07-18 17:45:41 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 784
ERROR - 2015-07-18 17:45:41 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:45:41 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:45:41 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:45:41 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:45:41 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:45:41 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:45:41 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:45:41 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:45:41 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:45:41 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:45:41 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:45:41 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:45:41 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:45:41 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 960
ERROR - 2015-07-18 17:45:41 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 960
ERROR - 2015-07-18 17:45:41 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 961
ERROR - 2015-07-18 17:45:41 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 17:46:17 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 818
ERROR - 2015-07-18 17:46:17 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 785
ERROR - 2015-07-18 17:46:17 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:46:17 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:46:17 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:46:17 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:46:17 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:46:17 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:46:17 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:46:17 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:46:17 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1815
ERROR - 2015-07-18 17:46:17 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:46:17 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:46:17 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:46:17 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:46:17 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 961
ERROR - 2015-07-18 17:46:17 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 961
ERROR - 2015-07-18 17:46:17 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 17:46:17 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 17:48:12 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 818
ERROR - 2015-07-18 17:48:12 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 785
ERROR - 2015-07-18 17:48:12 --> Severity: Notice --> Undefined offset: 9 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 653
ERROR - 2015-07-18 17:48:12 --> Severity: Notice --> Undefined offset: 10 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 653
ERROR - 2015-07-18 17:48:12 --> Severity: Notice --> Undefined offset: 11 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 653
ERROR - 2015-07-18 17:48:12 --> Severity: Notice --> Undefined offset: 12 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 653
ERROR - 2015-07-18 17:48:12 --> Severity: Notice --> Undefined offset: 13 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 653
ERROR - 2015-07-18 17:48:12 --> Severity: Notice --> Undefined offset: 14 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 653
ERROR - 2015-07-18 17:48:12 --> Severity: Notice --> Undefined offset: 15 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 653
ERROR - 2015-07-18 17:53:30 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 818
ERROR - 2015-07-18 17:53:30 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 785
ERROR - 2015-07-18 17:53:30 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 17:53:30 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 17:53:30 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 17:53:30 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 17:53:30 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 17:53:30 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 17:53:30 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 17:53:30 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 17:53:30 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 17:53:30 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:53:30 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 17:53:30 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:53:30 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 17:53:30 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 961
ERROR - 2015-07-18 17:53:30 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 961
ERROR - 2015-07-18 17:53:30 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 17:53:30 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 18:01:50 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 818
ERROR - 2015-07-18 18:01:50 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 785
ERROR - 2015-07-18 18:01:50 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:01:50 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:01:50 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:01:50 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:01:50 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:01:50 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:01:50 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:01:50 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:01:50 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:01:50 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:01:50 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:01:50 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:01:50 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:01:50 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 961
ERROR - 2015-07-18 18:01:50 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 961
ERROR - 2015-07-18 18:01:50 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:01:50 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 18:03:47 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 818
ERROR - 2015-07-18 18:03:47 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 785
ERROR - 2015-07-18 18:03:47 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:03:47 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:03:47 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:03:47 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:03:47 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:03:47 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:03:47 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:03:47 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:03:47 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:03:47 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:03:47 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:03:47 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:03:47 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:03:47 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 961
ERROR - 2015-07-18 18:03:47 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 961
ERROR - 2015-07-18 18:03:47 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:03:47 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 18:07:18 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 819
ERROR - 2015-07-18 18:07:18 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 786
ERROR - 2015-07-18 18:07:18 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:07:18 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:07:18 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:07:18 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:07:18 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:07:18 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:07:18 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:07:18 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:07:18 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:07:18 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:07:18 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:07:18 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:07:18 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:07:18 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:07:18 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:07:18 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 18:07:18 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 964
ERROR - 2015-07-18 18:08:25 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 819
ERROR - 2015-07-18 18:08:25 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 786
ERROR - 2015-07-18 18:08:25 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:08:25 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:08:25 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:08:25 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:08:25 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:08:25 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:08:25 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:08:25 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:08:25 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:08:25 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:08:25 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:08:25 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:08:25 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:08:25 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:08:25 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:08:25 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 18:08:25 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 964
ERROR - 2015-07-18 18:09:09 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 819
ERROR - 2015-07-18 18:09:09 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 786
ERROR - 2015-07-18 18:09:09 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:09:09 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:09:09 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:09:09 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:09:09 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:09:09 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:09:09 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:09:09 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:09:09 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:09:09 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:09:09 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:09:09 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:09:09 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:09:09 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:09:09 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:09:09 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 18:09:09 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 964
ERROR - 2015-07-18 18:11:41 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 819
ERROR - 2015-07-18 18:11:41 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 786
ERROR - 2015-07-18 18:11:41 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:11:41 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:11:41 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:11:41 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:11:41 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:11:41 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:11:41 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:11:41 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:11:41 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:11:41 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:11:41 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:11:41 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:11:41 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:11:41 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:11:41 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:11:41 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 18:11:41 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 964
ERROR - 2015-07-18 18:12:49 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 819
ERROR - 2015-07-18 18:12:49 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 786
ERROR - 2015-07-18 18:12:49 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:12:49 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:12:49 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:12:49 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:12:49 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:12:49 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:12:49 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:12:49 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:12:49 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1816
ERROR - 2015-07-18 18:12:49 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:12:49 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:12:49 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:12:49 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:12:49 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:12:49 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:12:49 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 18:12:49 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 964
ERROR - 2015-07-18 18:20:43 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 819
ERROR - 2015-07-18 18:20:43 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 786
ERROR - 2015-07-18 18:20:43 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:20:43 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:20:43 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:20:43 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:20:43 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:20:43 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:20:43 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:20:43 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:20:43 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:20:43 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:20:43 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:20:43 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:20:43 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:20:43 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:20:43 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:20:43 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 18:20:43 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 964
ERROR - 2015-07-18 18:22:24 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 819
ERROR - 2015-07-18 18:22:24 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 786
ERROR - 2015-07-18 18:22:24 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:22:24 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:22:24 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:22:24 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:22:24 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:22:24 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:22:24 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:22:24 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:22:24 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:22:24 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:22:24 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:22:24 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:22:24 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:22:24 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:22:24 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:22:24 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 18:22:24 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 964
ERROR - 2015-07-18 18:23:11 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 819
ERROR - 2015-07-18 18:23:11 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 786
ERROR - 2015-07-18 18:23:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:23:11 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:23:11 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:23:11 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:23:11 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:23:11 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:23:11 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:23:11 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:23:11 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1817
ERROR - 2015-07-18 18:23:11 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:23:11 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:23:11 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:23:11 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:23:11 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:23:11 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:23:11 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 18:23:11 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 964
ERROR - 2015-07-18 18:24:12 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 819
ERROR - 2015-07-18 18:24:12 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 786
ERROR - 2015-07-18 18:24:12 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:24:12 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:24:12 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:24:12 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:24:12 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:24:12 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:24:12 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:24:12 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:24:12 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:24:12 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:24:12 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:24:12 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:24:12 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:24:12 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:24:12 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:24:12 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 18:24:12 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 964
ERROR - 2015-07-18 18:24:39 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/registridev/modules/mara2/controllers/mara2.php 1706
ERROR - 2015-07-18 18:24:58 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/registridev/modules/mara2/controllers/mara2.php 1706
ERROR - 2015-07-18 18:25:10 --> Severity: Parsing Error --> syntax error, unexpected 'else' (T_ELSE) /var/www/html/registridev/modules/mara2/controllers/mara2.php 1706
ERROR - 2015-07-18 18:25:34 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 819
ERROR - 2015-07-18 18:25:34 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 786
ERROR - 2015-07-18 18:25:34 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:25:34 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:25:34 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:25:34 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:25:34 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:25:34 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:25:34 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:25:34 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:25:34 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:25:34 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:25:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:25:34 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:25:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:25:34 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:25:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:25:34 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 18:25:34 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 964
ERROR - 2015-07-18 18:27:46 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 819
ERROR - 2015-07-18 18:27:46 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 786
ERROR - 2015-07-18 18:27:46 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:27:46 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:27:46 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:27:46 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:27:46 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:27:46 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:27:46 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:27:46 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:27:46 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:27:46 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:27:46 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:27:46 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:27:46 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:27:46 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:27:46 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:27:46 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 18:27:46 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 964
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined variable: text16 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1697
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined variable: text16 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1697
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined variable: text16 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1697
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined variable: text16 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1697
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined variable: text16 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1697
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined variable: text16 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1697
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined variable: text16 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1697
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined variable: text16 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1697
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined variable: text16 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1697
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 819
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 786
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:28:45 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:28:45 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:28:45 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:28:45 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:28:45 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 18:28:45 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 964
ERROR - 2015-07-18 18:29:05 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 819
ERROR - 2015-07-18 18:29:05 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 786
ERROR - 2015-07-18 18:29:05 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:29:05 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:29:05 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:29:05 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:29:05 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:29:05 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:29:05 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:29:05 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:29:05 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:29:05 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:29:05 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:29:05 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:29:05 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:29:05 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:29:05 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:29:05 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 18:29:05 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 964
ERROR - 2015-07-18 18:29:59 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 819
ERROR - 2015-07-18 18:29:59 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 786
ERROR - 2015-07-18 18:29:59 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:29:59 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:29:59 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:29:59 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:29:59 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:29:59 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:29:59 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:29:59 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:29:59 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:29:59 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:29:59 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:29:59 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:29:59 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:29:59 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:29:59 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:29:59 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 18:29:59 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 964
ERROR - 2015-07-18 18:30:53 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 819
ERROR - 2015-07-18 18:30:53 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 786
ERROR - 2015-07-18 18:30:53 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:30:53 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:30:53 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:30:53 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:30:53 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:30:53 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:30:53 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:30:53 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:30:53 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 18:30:53 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:30:53 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 18:30:53 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:30:53 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 18:30:53 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:30:53 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 962
ERROR - 2015-07-18 18:30:53 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 18:30:53 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 964
ERROR - 2015-07-18 19:02:17 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 820
ERROR - 2015-07-18 19:02:17 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 787
ERROR - 2015-07-18 19:02:17 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:02:17 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:02:17 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:02:17 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:02:17 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:02:17 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:02:17 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:02:17 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:02:17 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:02:17 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:02:17 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:02:17 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:02:17 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:02:17 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 19:02:17 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 963
ERROR - 2015-07-18 19:02:17 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 964
ERROR - 2015-07-18 19:02:17 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 965
ERROR - 2015-07-18 19:05:29 --> Severity: Warning --> strstr(): needle is not a string or an integer /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 186
ERROR - 2015-07-18 19:05:29 --> Severity: Warning --> strstr(): needle is not a string or an integer /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 186
ERROR - 2015-07-18 19:05:29 --> Severity: Warning --> strstr(): needle is not a string or an integer /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 186
ERROR - 2015-07-18 19:05:29 --> Severity: Warning --> strstr(): needle is not a string or an integer /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 186
ERROR - 2015-07-18 19:05:29 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 822
ERROR - 2015-07-18 19:05:29 --> Severity: Warning --> strstr(): needle is not a string or an integer /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 186
ERROR - 2015-07-18 19:05:29 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 789
ERROR - 2015-07-18 19:05:29 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:05:29 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:05:29 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:05:29 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:05:29 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:05:29 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:05:29 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:05:29 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:05:29 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:05:29 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:05:29 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:05:29 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:05:29 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:05:29 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 965
ERROR - 2015-07-18 19:05:29 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 965
ERROR - 2015-07-18 19:05:29 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 966
ERROR - 2015-07-18 19:05:29 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 967
ERROR - 2015-07-18 19:05:59 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 822
ERROR - 2015-07-18 19:05:59 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 789
ERROR - 2015-07-18 19:05:59 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:05:59 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:05:59 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:05:59 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:05:59 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:05:59 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:05:59 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:05:59 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:05:59 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:05:59 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:05:59 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:05:59 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:05:59 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:05:59 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 965
ERROR - 2015-07-18 19:05:59 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 965
ERROR - 2015-07-18 19:05:59 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 966
ERROR - 2015-07-18 19:05:59 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 967
ERROR - 2015-07-18 19:10:40 --> Severity: Notice --> Undefined variable: array /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:10:40 --> Severity: Warning --> array_reverse() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:10:40 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:10:40 --> Severity: Notice --> Undefined variable: array /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:10:40 --> Severity: Warning --> array_reverse() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:10:40 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:10:40 --> Severity: Notice --> Undefined variable: array /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:10:40 --> Severity: Warning --> array_reverse() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:10:40 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:10:40 --> Severity: Notice --> Undefined variable: array /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:10:40 --> Severity: Warning --> array_reverse() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:10:40 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:10:40 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 828
ERROR - 2015-07-18 19:10:40 --> Severity: Notice --> Undefined variable: array /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:10:40 --> Severity: Warning --> array_reverse() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:10:40 --> Severity: Warning --> array_search() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:10:40 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 795
ERROR - 2015-07-18 19:10:40 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:10:40 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:10:40 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:10:40 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:10:40 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:10:40 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:10:40 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:10:40 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:10:40 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:10:40 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:10:40 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:10:40 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:10:40 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:10:40 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 971
ERROR - 2015-07-18 19:10:40 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 971
ERROR - 2015-07-18 19:10:40 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 972
ERROR - 2015-07-18 19:10:40 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 973
ERROR - 2015-07-18 19:12:18 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 828
ERROR - 2015-07-18 19:12:18 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 795
ERROR - 2015-07-18 19:12:18 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:12:18 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:12:18 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:12:18 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:12:18 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:12:18 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:12:18 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:12:18 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:12:18 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:12:18 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:12:18 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:12:18 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:12:18 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:12:18 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 971
ERROR - 2015-07-18 19:12:18 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 971
ERROR - 2015-07-18 19:12:18 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 972
ERROR - 2015-07-18 19:12:18 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 973
ERROR - 2015-07-18 19:13:04 --> Severity: Warning --> strstr(): needle is not a string or an integer /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:13:04 --> Severity: Warning --> strstr(): needle is not a string or an integer /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:13:04 --> Severity: Warning --> strstr(): needle is not a string or an integer /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:13:04 --> Severity: Warning --> strstr(): needle is not a string or an integer /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:13:04 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 828
ERROR - 2015-07-18 19:13:04 --> Severity: Warning --> strstr(): needle is not a string or an integer /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:13:04 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 795
ERROR - 2015-07-18 19:13:04 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:13:04 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:13:04 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:13:04 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:13:04 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:13:04 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:13:04 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:13:04 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:13:04 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:13:04 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:13:04 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:13:04 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:13:04 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:13:04 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 971
ERROR - 2015-07-18 19:13:04 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 971
ERROR - 2015-07-18 19:13:04 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 972
ERROR - 2015-07-18 19:13:04 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 973
ERROR - 2015-07-18 19:17:26 --> Severity: Warning --> strpos() expects at least 2 parameters, 1 given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:17:26 --> Severity: Warning --> strpos() expects at least 2 parameters, 1 given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:17:26 --> Severity: Warning --> strpos() expects at least 2 parameters, 1 given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:17:26 --> Severity: Warning --> strpos() expects at least 2 parameters, 1 given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:17:26 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 828
ERROR - 2015-07-18 19:17:26 --> Severity: Warning --> strpos() expects at least 2 parameters, 1 given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:17:26 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 795
ERROR - 2015-07-18 19:17:26 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:17:26 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:17:26 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:17:26 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:17:26 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:17:26 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:17:26 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:17:26 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:17:26 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:17:26 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:17:26 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:17:26 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:17:26 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:17:26 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 971
ERROR - 2015-07-18 19:17:26 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 971
ERROR - 2015-07-18 19:17:26 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 972
ERROR - 2015-07-18 19:17:26 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 973
ERROR - 2015-07-18 19:20:37 --> Severity: Warning --> strpos() expects at least 2 parameters, 1 given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:20:37 --> Severity: Warning --> strpos() expects at least 2 parameters, 1 given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:20:37 --> Severity: Warning --> strpos() expects at least 2 parameters, 1 given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:20:37 --> Severity: Warning --> strpos() expects at least 2 parameters, 1 given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:20:37 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 832
ERROR - 2015-07-18 19:20:37 --> Severity: Warning --> strpos() expects at least 2 parameters, 1 given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 193
ERROR - 2015-07-18 19:20:37 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 799
ERROR - 2015-07-18 19:20:37 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:20:37 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:20:37 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:20:37 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:20:37 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:20:37 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:20:37 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:20:37 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:20:37 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:20:37 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:20:37 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:20:37 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:20:37 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:20:37 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 975
ERROR - 2015-07-18 19:20:37 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 975
ERROR - 2015-07-18 19:20:37 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 976
ERROR - 2015-07-18 19:20:37 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 977
ERROR - 2015-07-18 19:20:59 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 832
ERROR - 2015-07-18 19:20:59 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 799
ERROR - 2015-07-18 19:20:59 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:20:59 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:20:59 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:20:59 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:20:59 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:20:59 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:20:59 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:20:59 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:20:59 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:20:59 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:20:59 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:20:59 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:20:59 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:20:59 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 975
ERROR - 2015-07-18 19:20:59 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 975
ERROR - 2015-07-18 19:20:59 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 976
ERROR - 2015-07-18 19:20:59 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 977
ERROR - 2015-07-18 19:21:28 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 832
ERROR - 2015-07-18 19:21:28 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 799
ERROR - 2015-07-18 19:21:28 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:21:28 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:21:28 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:21:28 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:21:28 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:21:28 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:21:28 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:21:28 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:21:28 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:21:28 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:21:28 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:21:28 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:21:28 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:21:28 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 975
ERROR - 2015-07-18 19:21:28 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 975
ERROR - 2015-07-18 19:21:28 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 976
ERROR - 2015-07-18 19:21:28 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 977
ERROR - 2015-07-18 19:25:40 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 836
ERROR - 2015-07-18 19:25:40 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 803
ERROR - 2015-07-18 19:25:40 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:25:40 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:25:40 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:25:40 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:25:40 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:25:40 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:25:40 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:25:40 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:25:40 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:25:40 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:25:40 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:25:40 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:25:40 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:25:40 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 979
ERROR - 2015-07-18 19:25:40 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 979
ERROR - 2015-07-18 19:25:40 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:25:40 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 981
ERROR - 2015-07-18 19:26:11 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 836
ERROR - 2015-07-18 19:26:11 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 803
ERROR - 2015-07-18 19:26:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:26:11 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:26:11 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:26:11 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:26:11 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:26:11 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:26:11 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:26:11 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:26:11 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:26:11 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:26:11 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:26:11 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:26:11 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:26:11 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 979
ERROR - 2015-07-18 19:26:11 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 979
ERROR - 2015-07-18 19:26:11 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:26:11 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 981
ERROR - 2015-07-18 19:26:46 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 837
ERROR - 2015-07-18 19:26:46 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 804
ERROR - 2015-07-18 19:26:46 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:26:46 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:26:46 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:26:46 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:26:46 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:26:46 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:26:46 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:26:46 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:26:46 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:26:46 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:26:46 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:26:46 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:26:46 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:26:46 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:26:46 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:26:46 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 981
ERROR - 2015-07-18 19:26:46 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 982
ERROR - 2015-07-18 19:27:15 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 837
ERROR - 2015-07-18 19:27:15 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 804
ERROR - 2015-07-18 19:27:15 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:27:15 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:27:15 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:27:15 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:27:15 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:27:15 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:27:15 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:27:15 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:27:15 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:27:15 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:27:15 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:27:15 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:27:15 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:27:15 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:27:15 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:27:15 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 981
ERROR - 2015-07-18 19:27:15 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 982
ERROR - 2015-07-18 19:28:18 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 837
ERROR - 2015-07-18 19:28:18 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 804
ERROR - 2015-07-18 19:28:18 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:28:18 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:28:18 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:28:18 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:28:18 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:28:18 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:28:18 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:28:18 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:28:18 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:28:18 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:28:18 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:28:18 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:28:18 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:28:18 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:28:18 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:28:18 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 981
ERROR - 2015-07-18 19:28:18 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 982
ERROR - 2015-07-18 19:28:46 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 837
ERROR - 2015-07-18 19:28:46 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 804
ERROR - 2015-07-18 19:28:46 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:28:46 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:28:46 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:28:46 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:28:46 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:28:46 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:28:46 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:28:46 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:28:46 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:28:46 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:28:46 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:28:46 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:28:46 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:28:46 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:28:46 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:28:46 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 981
ERROR - 2015-07-18 19:28:46 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 982
ERROR - 2015-07-18 19:29:32 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 837
ERROR - 2015-07-18 19:29:32 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 804
ERROR - 2015-07-18 19:29:32 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:29:32 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:29:32 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:29:32 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:29:32 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:29:32 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:29:32 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:29:32 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:29:32 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:29:32 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:29:32 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:29:32 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:29:32 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:29:32 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:29:32 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:29:32 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 981
ERROR - 2015-07-18 19:29:32 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 982
ERROR - 2015-07-18 19:29:56 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 837
ERROR - 2015-07-18 19:29:56 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 804
ERROR - 2015-07-18 19:29:56 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:29:56 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:29:56 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:29:56 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:29:56 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:29:56 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:29:56 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:29:56 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:29:56 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:29:56 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:29:56 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:29:56 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:29:56 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:29:56 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:29:56 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:29:56 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 981
ERROR - 2015-07-18 19:29:56 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 982
ERROR - 2015-07-18 19:30:25 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 837
ERROR - 2015-07-18 19:30:25 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 804
ERROR - 2015-07-18 19:30:25 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:30:25 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:30:25 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:30:25 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:30:25 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:30:25 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:30:25 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:30:25 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:30:25 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:30:25 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:30:25 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:30:25 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:30:25 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:30:25 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:30:25 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:30:25 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 981
ERROR - 2015-07-18 19:30:25 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 982
ERROR - 2015-07-18 19:32:21 --> Severity: Parsing Error --> syntax error, unexpected 'echo' (T_ECHO) /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 204
ERROR - 2015-07-18 19:32:40 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 837
ERROR - 2015-07-18 19:32:40 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 804
ERROR - 2015-07-18 19:32:40 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:32:40 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:32:40 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:32:40 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:32:40 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:32:40 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:32:40 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:32:40 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:32:40 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:32:40 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:32:40 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:32:40 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:32:40 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:32:40 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:32:40 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:32:40 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 981
ERROR - 2015-07-18 19:32:40 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 982
ERROR - 2015-07-18 19:34:00 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 837
ERROR - 2015-07-18 19:34:00 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 804
ERROR - 2015-07-18 19:34:00 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:34:00 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:34:00 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:34:00 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:34:00 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:34:00 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:34:00 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:34:00 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:34:00 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:34:00 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:34:00 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:34:00 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:34:00 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:34:00 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:34:00 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:34:00 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 981
ERROR - 2015-07-18 19:34:00 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 982
ERROR - 2015-07-18 19:36:36 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:36:36 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:36:36 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:36:36 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:36:36 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:36:36 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:36:36 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:36:36 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:36:36 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:36:36 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:36:36 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:36:36 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:36:36 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:36:36 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 979
ERROR - 2015-07-18 19:36:36 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 979
ERROR - 2015-07-18 19:36:36 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:36:36 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 981
ERROR - 2015-07-18 19:38:28 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1819
ERROR - 2015-07-18 19:38:28 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1819
ERROR - 2015-07-18 19:38:28 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1819
ERROR - 2015-07-18 19:38:28 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1819
ERROR - 2015-07-18 19:38:28 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1819
ERROR - 2015-07-18 19:38:28 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1819
ERROR - 2015-07-18 19:38:28 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1819
ERROR - 2015-07-18 19:38:28 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1819
ERROR - 2015-07-18 19:38:28 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1819
ERROR - 2015-07-18 19:38:28 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:38:28 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:38:28 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:38:28 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:38:28 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 977
ERROR - 2015-07-18 19:38:28 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 977
ERROR - 2015-07-18 19:38:28 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 978
ERROR - 2015-07-18 19:38:28 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 979
ERROR - 2015-07-18 19:39:39 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:39:39 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:39:39 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:39:39 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:39:39 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:39:39 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:39:39 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:39:39 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:39:39 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:39:39 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:39:39 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:39:39 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:39:39 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:39:39 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 977
ERROR - 2015-07-18 19:39:39 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 977
ERROR - 2015-07-18 19:39:39 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 978
ERROR - 2015-07-18 19:39:39 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 979
ERROR - 2015-07-18 19:40:11 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:40:11 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:40:11 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:40:11 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:40:11 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:40:11 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:40:11 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:40:11 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:40:11 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:40:11 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:40:11 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:40:11 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:40:11 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:40:11 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 977
ERROR - 2015-07-18 19:40:11 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 977
ERROR - 2015-07-18 19:40:11 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 978
ERROR - 2015-07-18 19:40:11 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 979
ERROR - 2015-07-18 19:41:35 --> Severity: Notice --> Undefined offset: 9 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 669
ERROR - 2015-07-18 19:41:35 --> Severity: Notice --> Undefined offset: 10 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 669
ERROR - 2015-07-18 19:41:35 --> Severity: Notice --> Undefined offset: 11 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 669
ERROR - 2015-07-18 19:41:35 --> Severity: Notice --> Undefined offset: 12 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 669
ERROR - 2015-07-18 19:41:35 --> Severity: Notice --> Undefined offset: 13 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 669
ERROR - 2015-07-18 19:41:35 --> Severity: Notice --> Undefined offset: 14 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 669
ERROR - 2015-07-18 19:41:35 --> Severity: Notice --> Undefined offset: 15 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 669
ERROR - 2015-07-18 19:45:58 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:45:58 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:45:58 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:45:58 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:45:58 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:45:58 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:45:58 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:45:58 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:45:58 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:45:58 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:45:58 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:45:58 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:45:58 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:45:58 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 977
ERROR - 2015-07-18 19:45:58 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 977
ERROR - 2015-07-18 19:45:58 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 978
ERROR - 2015-07-18 19:45:58 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 979
ERROR - 2015-07-18 19:47:08 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:47:08 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:47:08 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:47:08 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:47:08 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:47:08 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:47:08 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:47:08 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:47:08 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:47:08 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:47:08 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:47:08 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:47:08 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:47:08 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 978
ERROR - 2015-07-18 19:47:08 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 978
ERROR - 2015-07-18 19:47:08 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 979
ERROR - 2015-07-18 19:47:08 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:47:30 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:47:30 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:47:30 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:47:30 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:47:30 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:47:30 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:47:30 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:47:30 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:47:30 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:47:30 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:47:30 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:47:30 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:47:30 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:47:30 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 979
ERROR - 2015-07-18 19:47:30 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 979
ERROR - 2015-07-18 19:47:30 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:47:30 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 981
ERROR - 2015-07-18 19:48:01 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:48:01 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:48:01 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:48:01 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:48:01 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:48:01 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:48:01 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:48:01 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:48:01 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:48:01 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:48:01 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:48:01 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:48:01 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:48:01 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 979
ERROR - 2015-07-18 19:48:01 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 979
ERROR - 2015-07-18 19:48:01 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:48:01 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 981
ERROR - 2015-07-18 19:51:28 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:51:28 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:51:28 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:51:28 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:51:28 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:51:28 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:51:28 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:51:28 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:51:28 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:51:28 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:51:28 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:51:28 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:51:28 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:51:28 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:51:28 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:51:28 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1818
ERROR - 2015-07-18 19:51:28 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:51:28 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 19:51:28 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:51:28 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 19:51:28 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 979
ERROR - 2015-07-18 19:51:28 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 979
ERROR - 2015-07-18 19:51:28 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 980
ERROR - 2015-07-18 19:51:28 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 981
ERROR - 2015-07-18 19:55:01 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 836
ERROR - 2015-07-18 19:55:01 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 803
ERROR - 2015-07-18 19:55:01 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 836
ERROR - 2015-07-18 19:55:01 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 803
ERROR - 2015-07-18 19:55:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-18 20:08:27 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 836
ERROR - 2015-07-18 20:08:28 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 803
ERROR - 2015-07-18 20:08:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-18 20:10:26 --> Severity: Notice --> Undefined index: partitions /var/www/html/registridev/modules/mara2/controllers/mara2.php 1458
ERROR - 2015-07-18 20:10:26 --> Severity: Notice --> Undefined index: partSel /var/www/html/registridev/modules/mara2/controllers/mara2.php 1459
ERROR - 2015-07-18 20:10:26 --> Severity: Notice --> Undefined index: editPartition /var/www/html/registridev/modules/mara2/controllers/mara2.php 1460
ERROR - 2015-07-18 20:10:26 --> Severity: Notice --> Undefined index: partId /var/www/html/registridev/modules/mara2/controllers/mara2.php 1461
ERROR - 2015-07-18 20:10:26 --> Severity: Notice --> Undefined index: partId /var/www/html/registridev/modules/mara2/controllers/mara2.php 1462
ERROR - 2015-07-18 20:10:26 --> Query error: Table 'registridev.ra_mara__document' doesn't exist - Invalid query: SELECT reg_part_id FROM ra_mara__document
ERROR - 2015-07-18 20:13:04 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 836
ERROR - 2015-07-18 20:13:04 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 803
ERROR - 2015-07-18 20:13:04 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/modules/mara2/controllers/maraAPI.php:831) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-18 20:14:38 --> Severity: Notice --> Undefined index: partitions /var/www/html/registridev/modules/mara2/controllers/mara2.php 1458
ERROR - 2015-07-18 20:14:38 --> Severity: Notice --> Undefined index: partSel /var/www/html/registridev/modules/mara2/controllers/mara2.php 1459
ERROR - 2015-07-18 20:14:38 --> Severity: Notice --> Undefined index: editPartition /var/www/html/registridev/modules/mara2/controllers/mara2.php 1460
ERROR - 2015-07-18 20:14:38 --> Severity: Notice --> Undefined index: partId /var/www/html/registridev/modules/mara2/controllers/mara2.php 1461
ERROR - 2015-07-18 20:14:38 --> Severity: Notice --> Undefined index: partId /var/www/html/registridev/modules/mara2/controllers/mara2.php 1462
ERROR - 2015-07-18 20:25:05 --> Severity: Notice --> Undefined index: partitions /var/www/html/registridev/modules/mara2/controllers/mara2.php 1458
ERROR - 2015-07-18 20:25:05 --> Severity: Notice --> Undefined index: partSel /var/www/html/registridev/modules/mara2/controllers/mara2.php 1459
ERROR - 2015-07-18 20:25:05 --> Severity: Notice --> Undefined index: editPartition /var/www/html/registridev/modules/mara2/controllers/mara2.php 1460
ERROR - 2015-07-18 20:25:05 --> Severity: Notice --> Undefined index: partId /var/www/html/registridev/modules/mara2/controllers/mara2.php 1461
ERROR - 2015-07-18 20:25:05 --> Severity: Notice --> Undefined index: partId /var/www/html/registridev/modules/mara2/controllers/mara2.php 1462
ERROR - 2015-07-18 20:28:18 --> Severity: Notice --> Undefined index: partitions /var/www/html/registridev/modules/mara2/controllers/mara2.php 1458
ERROR - 2015-07-18 20:28:18 --> Severity: Notice --> Undefined index: partSel /var/www/html/registridev/modules/mara2/controllers/mara2.php 1459
ERROR - 2015-07-18 20:28:18 --> Severity: Notice --> Undefined index: editPartition /var/www/html/registridev/modules/mara2/controllers/mara2.php 1460
ERROR - 2015-07-18 20:28:18 --> Severity: Notice --> Undefined index: partId /var/www/html/registridev/modules/mara2/controllers/mara2.php 1461
ERROR - 2015-07-18 20:28:18 --> Severity: Notice --> Undefined index: partId /var/www/html/registridev/modules/mara2/controllers/mara2.php 1462
ERROR - 2015-07-18 20:36:27 --> Severity: Parsing Error --> syntax error, unexpected '{' /var/www/html/registridev/modules/mara2/controllers/mara2.php 1606
ERROR - 2015-07-18 20:36:38 --> Severity: Parsing Error --> syntax error, unexpected '}', expecting ';' /var/www/html/registridev/modules/mara2/controllers/mara2.php 1608
ERROR - 2015-07-18 20:39:37 --> Severity: Notice --> Undefined offset: 9 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 671
ERROR - 2015-07-18 20:39:37 --> Severity: Notice --> Undefined offset: 10 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 671
ERROR - 2015-07-18 20:39:37 --> Severity: Notice --> Undefined offset: 11 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 671
ERROR - 2015-07-18 20:39:37 --> Severity: Notice --> Undefined offset: 12 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 671
ERROR - 2015-07-18 20:39:37 --> Severity: Notice --> Undefined offset: 13 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 671
ERROR - 2015-07-18 20:39:37 --> Severity: Notice --> Undefined offset: 14 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 671
ERROR - 2015-07-18 20:39:37 --> Severity: Notice --> Undefined offset: 15 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 671
ERROR - 2015-07-18 20:44:42 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:44:42 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:44:42 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:44:42 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:44:42 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:44:42 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:44:42 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:44:42 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:44:42 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:44:42 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:44:42 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:44:42 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:44:42 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:44:42 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:44:42 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:44:42 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:44:42 --> Query error: Column 'document_id' cannot be null - Invalid query: INSERT INTO `ra_mara_RA06_source` (`document_id`, `reg_part_id`, `brute`, `tradizione`) VALUES (NULL, 'RA06.01', 'Sicola, Repertorium Caroli 2, f. 113#;# Chiarito, Repertorium III, f. 346.', 'Sicola, Repertorium Caroli 2, f. 113')
ERROR - 2015-07-18 20:44:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/modules/mara2/controllers/maraAPI.php:831) /var/www/html/registridev/system/core/Common.php 550
ERROR - 2015-07-18 20:46:56 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:46:56 --> Severity: Notice --> Undefined offset: 0 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:46:56 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:46:56 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:46:56 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:46:56 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:46:56 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:46:56 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:46:56 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:46:56 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:46:56 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:46:56 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:46:56 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:46:56 --> Severity: Notice --> Undefined offset: 6 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:46:56 --> Severity: Notice --> Undefined offset: 7 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:46:56 --> Severity: Notice --> Undefined offset: 8 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1825
ERROR - 2015-07-18 20:46:56 --> Query error: Column 'document_id' cannot be null - Invalid query: INSERT INTO `ra_mara_RA06_source` (`document_id`, `reg_part_id`, `brute`, `tradizione`) VALUES (NULL, 'RA06.01', 'Sicola, Repertorium Caroli 2, f. 113#;# Chiarito, Repertorium III, f. 346.', 'Sicola, Repertorium Caroli 2, f. 113')
ERROR - 2015-07-18 20:46:56 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/modules/mara2/controllers/maraAPI.php:831) /var/www/html/registridev/system/core/Common.php 550
ERROR - 2015-07-18 21:02:24 --> Severity: Notice --> Undefined index: partitions /var/www/html/registridev/modules/mara2/controllers/mara2.php 1458
ERROR - 2015-07-18 21:02:24 --> Severity: Notice --> Undefined index: partSel /var/www/html/registridev/modules/mara2/controllers/mara2.php 1459
ERROR - 2015-07-18 21:02:24 --> Severity: Notice --> Undefined index: editPartition /var/www/html/registridev/modules/mara2/controllers/mara2.php 1460
ERROR - 2015-07-18 21:02:24 --> Severity: Notice --> Undefined index: partId /var/www/html/registridev/modules/mara2/controllers/mara2.php 1461
ERROR - 2015-07-18 21:02:24 --> Severity: Notice --> Undefined index: partId /var/www/html/registridev/modules/mara2/controllers/mara2.php 1462
ERROR - 2015-07-18 21:02:24 --> Query error: Table 'registridev.ra_mara__document' doesn't exist - Invalid query: SELECT reg_part_id FROM ra_mara__document
ERROR - 2015-07-18 21:11:40 --> Severity: Notice --> Undefined index: partitions /var/www/html/registridev/modules/mara2/controllers/mara2.php 1458
ERROR - 2015-07-18 21:11:40 --> Severity: Notice --> Undefined index: partSel /var/www/html/registridev/modules/mara2/controllers/mara2.php 1459
ERROR - 2015-07-18 21:11:40 --> Severity: Notice --> Undefined index: editPartition /var/www/html/registridev/modules/mara2/controllers/mara2.php 1460
ERROR - 2015-07-18 21:11:40 --> Severity: Notice --> Undefined index: partId /var/www/html/registridev/modules/mara2/controllers/mara2.php 1461
ERROR - 2015-07-18 21:11:40 --> Severity: Notice --> Undefined index: partId /var/www/html/registridev/modules/mara2/controllers/mara2.php 1462
ERROR - 2015-07-18 21:11:40 --> Query error: Table 'registridev.ra_mara__document' doesn't exist - Invalid query: SELECT reg_part_id FROM ra_mara__document
ERROR - 2015-07-18 21:20:01 --> Severity: Notice --> Undefined variable: partContents /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 183
ERROR - 2015-07-18 21:25:25 --> 404 Page Not Found: mara2/mara2
ERROR - 2015-07-18 21:25:53 --> Severity: Notice --> Undefined offset: 9 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 443
ERROR - 2015-07-18 21:25:53 --> Severity: Notice --> Undefined offset: 10 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 443
ERROR - 2015-07-18 21:25:53 --> Severity: Notice --> Undefined offset: 11 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 443
ERROR - 2015-07-18 21:25:53 --> Severity: Notice --> Undefined offset: 12 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 443
ERROR - 2015-07-18 21:25:53 --> Severity: Notice --> Undefined offset: 13 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 443
ERROR - 2015-07-18 21:25:53 --> Severity: Notice --> Undefined offset: 14 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 443
ERROR - 2015-07-18 21:25:53 --> Severity: Notice --> Undefined offset: 15 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 443
ERROR - 2015-07-18 21:25:53 --> Severity: Notice --> Undefined offset: 16 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 443
ERROR - 2015-07-18 21:25:53 --> Severity: Notice --> Undefined offset: 17 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 443
ERROR - 2015-07-18 21:25:53 --> Severity: Notice --> Undefined offset: 18 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 443
ERROR - 2015-07-18 21:25:53 --> Severity: Notice --> Undefined offset: 19 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 443
ERROR - 2015-07-18 21:25:53 --> Severity: Notice --> Undefined offset: 20 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 443
ERROR - 2015-07-18 21:25:53 --> Severity: Notice --> Undefined offset: 21 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 443
ERROR - 2015-07-18 21:25:53 --> Severity: Notice --> Undefined offset: 22 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 443
ERROR - 2015-07-18 21:25:53 --> Severity: Notice --> Undefined offset: 23 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 443
ERROR - 2015-07-18 21:25:53 --> Severity: Notice --> Undefined offset: 24 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 443
ERROR - 2015-07-18 21:25:53 --> Severity: Notice --> Undefined offset: 25 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 443
ERROR - 2015-07-18 21:25:53 --> Severity: Notice --> Undefined offset: 26 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 443
ERROR - 2015-07-18 22:59:27 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 209
ERROR - 2015-07-18 22:59:27 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 209
ERROR - 2015-07-18 22:59:27 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 209
ERROR - 2015-07-18 22:59:27 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 209
ERROR - 2015-07-18 22:59:27 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 209
ERROR - 2015-07-18 23:05:41 --> Severity: Notice --> Undefined variable: ras /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 209
ERROR - 2015-07-18 23:05:41 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 210
ERROR - 2015-07-18 23:05:41 --> Severity: Notice --> Undefined variable: ras /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 209
ERROR - 2015-07-18 23:05:41 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 210
ERROR - 2015-07-18 23:05:41 --> Severity: Notice --> Undefined variable: ras /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 209
ERROR - 2015-07-18 23:05:41 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 210
ERROR - 2015-07-18 23:05:41 --> Severity: Notice --> Undefined variable: ras /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 209
ERROR - 2015-07-18 23:05:41 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 210
ERROR - 2015-07-18 23:05:41 --> Severity: Notice --> Undefined variable: ras /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 209
ERROR - 2015-07-18 23:05:41 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 210
ERROR - 2015-07-18 23:05:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-18 23:09:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/modules/mara2/controllers/maraAPI.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-18 23:16:41 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:16:41 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:16:41 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:16:41 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:16:41 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 988
ERROR - 2015-07-18 23:16:41 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 988
ERROR - 2015-07-18 23:16:41 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 989
ERROR - 2015-07-18 23:16:41 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 990
ERROR - 2015-07-18 23:17:53 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:17:53 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:17:53 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:17:53 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:17:53 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 988
ERROR - 2015-07-18 23:17:53 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 988
ERROR - 2015-07-18 23:17:53 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 989
ERROR - 2015-07-18 23:17:53 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 990
ERROR - 2015-07-18 23:21:45 --> Severity: Notice --> Undefined variable: ras /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 211
ERROR - 2015-07-18 23:21:45 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 212
ERROR - 2015-07-18 23:21:45 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:21:45 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:21:45 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:21:45 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:21:45 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 988
ERROR - 2015-07-18 23:21:45 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 988
ERROR - 2015-07-18 23:21:45 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 989
ERROR - 2015-07-18 23:21:45 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 990
ERROR - 2015-07-18 23:28:20 --> Severity: Notice --> Undefined variable: ras /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 214
ERROR - 2015-07-18 23:28:20 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 216
ERROR - 2015-07-18 23:28:20 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:28:20 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:28:20 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:28:20 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:28:20 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 992
ERROR - 2015-07-18 23:28:20 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 992
ERROR - 2015-07-18 23:28:20 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 993
ERROR - 2015-07-18 23:28:20 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 994
ERROR - 2015-07-18 23:29:55 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:29:55 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:29:55 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:29:55 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:29:55 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 996
ERROR - 2015-07-18 23:29:55 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 996
ERROR - 2015-07-18 23:29:55 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 997
ERROR - 2015-07-18 23:29:55 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 998
ERROR - 2015-07-18 23:30:47 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:30:47 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:30:47 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:30:47 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:30:47 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 997
ERROR - 2015-07-18 23:30:47 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 997
ERROR - 2015-07-18 23:30:47 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 998
ERROR - 2015-07-18 23:30:47 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 999
ERROR - 2015-07-18 23:31:22 --> Severity: Notice --> Undefined variable: ras /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 210
ERROR - 2015-07-18 23:31:22 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:31:22 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:31:22 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:31:22 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:31:22 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 997
ERROR - 2015-07-18 23:31:22 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 997
ERROR - 2015-07-18 23:31:22 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 998
ERROR - 2015-07-18 23:31:22 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 999
ERROR - 2015-07-18 23:34:35 --> Severity: Notice --> Undefined variable: ras /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 213
ERROR - 2015-07-18 23:34:35 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:34:35 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:34:35 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:34:35 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:34:35 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1002
ERROR - 2015-07-18 23:34:35 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1002
ERROR - 2015-07-18 23:34:35 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1003
ERROR - 2015-07-18 23:34:35 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1004
ERROR - 2015-07-18 23:36:45 --> Severity: Parsing Error --> syntax error, unexpected '}' /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 218
ERROR - 2015-07-18 23:37:08 --> Severity: Notice --> Undefined variable: ras /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 213
ERROR - 2015-07-18 23:37:08 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:37:08 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:37:08 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:37:08 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:37:08 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1000
ERROR - 2015-07-18 23:37:08 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1000
ERROR - 2015-07-18 23:37:08 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1001
ERROR - 2015-07-18 23:37:08 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1002
ERROR - 2015-07-18 23:38:33 --> Severity: Notice --> Undefined variable: ras /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 213
ERROR - 2015-07-18 23:38:33 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:38:33 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:38:33 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:38:33 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:38:33 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1000
ERROR - 2015-07-18 23:38:33 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1000
ERROR - 2015-07-18 23:38:33 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1001
ERROR - 2015-07-18 23:38:33 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1002
ERROR - 2015-07-18 23:39:07 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:39:07 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:39:07 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:39:07 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:39:07 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1000
ERROR - 2015-07-18 23:39:07 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1000
ERROR - 2015-07-18 23:39:07 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1001
ERROR - 2015-07-18 23:39:07 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1002
ERROR - 2015-07-18 23:41:35 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:41:35 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:41:35 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:41:35 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:41:35 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1000
ERROR - 2015-07-18 23:41:35 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1000
ERROR - 2015-07-18 23:41:35 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1001
ERROR - 2015-07-18 23:41:35 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1002
ERROR - 2015-07-18 23:44:34 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:44:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:44:34 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:44:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:44:34 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1003
ERROR - 2015-07-18 23:44:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1003
ERROR - 2015-07-18 23:44:34 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1004
ERROR - 2015-07-18 23:44:34 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1005
ERROR - 2015-07-18 23:45:34 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:45:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:45:34 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:45:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:45:34 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1004
ERROR - 2015-07-18 23:45:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1004
ERROR - 2015-07-18 23:45:34 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1005
ERROR - 2015-07-18 23:45:34 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1006
ERROR - 2015-07-18 23:46:19 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:46:19 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:46:19 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:46:19 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:46:19 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1006
ERROR - 2015-07-18 23:46:19 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1006
ERROR - 2015-07-18 23:46:19 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1007
ERROR - 2015-07-18 23:46:19 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1008
ERROR - 2015-07-18 23:46:35 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:46:35 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:46:35 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:46:35 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:46:35 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1006
ERROR - 2015-07-18 23:46:35 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1006
ERROR - 2015-07-18 23:46:35 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1007
ERROR - 2015-07-18 23:46:35 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1008
ERROR - 2015-07-18 23:47:05 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:47:05 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:47:05 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:47:05 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:47:05 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1006
ERROR - 2015-07-18 23:47:05 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1006
ERROR - 2015-07-18 23:47:05 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1007
ERROR - 2015-07-18 23:47:05 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1008
ERROR - 2015-07-18 23:47:34 --> Severity: Notice --> Undefined variable: roDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:47:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1488
ERROR - 2015-07-18 23:47:34 --> Severity: Notice --> Undefined variable: soDid /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:47:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 1493
ERROR - 2015-07-18 23:47:34 --> Severity: Notice --> Undefined variable: keys /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1006
ERROR - 2015-07-18 23:47:34 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1006
ERROR - 2015-07-18 23:47:34 --> Severity: Warning --> array_values() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1007
ERROR - 2015-07-18 23:47:34 --> Severity: Warning --> array_flip() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1008
ERROR - 2015-07-18 23:59:06 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 218
ERROR - 2015-07-18 23:59:06 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 218
ERROR - 2015-07-18 23:59:06 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 218
ERROR - 2015-07-18 23:59:06 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 218
ERROR - 2015-07-18 23:59:06 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 218
