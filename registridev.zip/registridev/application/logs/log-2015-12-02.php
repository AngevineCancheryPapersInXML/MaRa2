<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-02 02:22:20 --> 404 Page Not Found: mara2/mara2
ERROR - 2015-12-02 02:23:16 --> 404 Page Not Found: mara2/step2b
ERROR - 2015-12-02 02:23:23 --> 404 Page Not Found: mara2/step2b
ERROR - 2015-12-02 02:23:28 --> 404 Page Not Found: mara2/step2b
ERROR - 2015-12-02 02:23:31 --> 404 Page Not Found: mara2/mara2
ERROR - 2015-12-02 02:23:46 --> 404 Page Not Found: mara2/mara2
