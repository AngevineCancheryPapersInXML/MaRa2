<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-12-03 19:48:57 --> 404 Page Not Found: mara2/mara2
