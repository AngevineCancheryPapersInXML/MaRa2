<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-02 09:57:51 --> Severity: Notice --> Undefined variable: names /var/www/html/registridev/modules/mara2/controllers/mara2.php 29
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> array_unique() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 29
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> in_array() expects parameter 2 to be array, null given /var/www/html/registridev/modules/mara2/controllers/mara2.php 44
ERROR - 2018-10-02 09:57:51 --> Severity: Notice --> Undefined variable: status /var/www/html/registridev/modules/mara2/controllers/mara2.php 52
ERROR - 2018-10-02 09:57:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/libraries/Session/drivers/Session_cookie.php 734
ERROR - 2018-10-02 10:51:49 --> Severity: Notice --> Undefined variable: alertclass /var/www/html/registridev/modules/mara2/controllers/mara2.php 96
ERROR - 2018-10-02 11:40:08 --> Severity: Notice --> Undefined offset: 4 /var/www/html/registridev/modules/mara2/controllers/mara_functions.php 706
ERROR - 2018-10-02 11:40:08 --> Severity: Notice --> Undefined offset: 5 /var/www/html/registridev/modules/mara2/controllers/mara_functions.php 706
