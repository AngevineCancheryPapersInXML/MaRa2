<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-02-14 10:17:22 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1769
ERROR - 2017-02-14 10:17:22 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1769
ERROR - 2017-02-14 10:17:22 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1769
ERROR - 2017-02-14 10:17:22 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1769
ERROR - 2017-02-14 10:17:22 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1769
ERROR - 2017-02-14 10:17:22 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1794
ERROR - 2017-02-14 10:17:22 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1794
ERROR - 2017-02-14 10:17:22 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1794
ERROR - 2017-02-14 10:17:22 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1794
ERROR - 2017-02-14 10:17:22 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1794
ERROR - 2017-02-14 10:18:00 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1724
