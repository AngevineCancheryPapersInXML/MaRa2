<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-08 12:12:00 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-08 12:12:50 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-08 12:12:59 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-08 12:14:13 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
