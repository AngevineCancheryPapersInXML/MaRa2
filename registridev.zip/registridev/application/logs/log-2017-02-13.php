<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-02-13 18:05:33 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1724
