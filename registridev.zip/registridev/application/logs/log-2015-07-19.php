<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2015-07-19 00:21:49 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 215
ERROR - 2015-07-19 00:21:49 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 215
ERROR - 2015-07-19 00:21:49 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 215
ERROR - 2015-07-19 00:21:49 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 215
ERROR - 2015-07-19 00:21:49 --> Severity: Warning --> end() expects parameter 1 to be array, null given /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 215
ERROR - 2015-07-19 00:21:49 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/modules/mara2/controllers/maraAPI.php:194) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-19 00:25:12 --> 404 Page Not Found: mara2/mara2
ERROR - 2015-07-19 00:26:56 --> 404 Page Not Found: mara2/mara2
ERROR - 2015-07-19 00:27:26 --> 404 Page Not Found: mara2/mara2
ERROR - 2015-07-19 00:37:30 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 00:37:30 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 00:37:30 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 00:37:30 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 00:37:31 --> Severity: Notice --> Undefined offset: 10 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 00:37:31 --> Severity: Notice --> Undefined offset: 10 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:37:31 --> Severity: Notice --> Undefined offset: 10 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 27 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 27 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 28 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 29 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 30 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 31 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 32 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 33 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 34 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 35 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 36 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 37 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 38 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 39 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 40 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 41 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 42 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 43 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 44 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 45 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 46 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 47 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 48 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 49 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 50 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 51 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 52 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 53 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 54 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 55 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 56 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 57 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 58 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 59 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 60 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 61 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 62 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 63 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 64 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 65 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 66 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 67 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 68 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 69 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 70 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 71 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 72 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:40:09 --> Severity: Notice --> Undefined offset: 27 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 00:46:37 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 00:46:37 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 00:46:38 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 00:46:38 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 00:46:39 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 00:46:39 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 00:46:40 --> Severity: Notice --> Undefined offset: 59 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 00:46:40 --> Severity: Notice --> Undefined offset: 59 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:46:40 --> Severity: Notice --> Undefined offset: 60 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:46:40 --> Severity: Notice --> Undefined offset: 61 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:46:40 --> Severity: Notice --> Undefined offset: 62 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:46:40 --> Severity: Notice --> Undefined offset: 63 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:46:40 --> Severity: Notice --> Undefined offset: 64 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:46:40 --> Severity: Notice --> Undefined offset: 65 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:46:40 --> Severity: Notice --> Undefined offset: 66 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:46:40 --> Severity: Notice --> Undefined offset: 67 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:46:40 --> Severity: Notice --> Undefined offset: 68 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:46:40 --> Severity: Notice --> Undefined offset: 69 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:46:40 --> Severity: Notice --> Undefined offset: 70 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:46:40 --> Severity: Notice --> Undefined offset: 71 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:46:40 --> Severity: Notice --> Undefined offset: 72 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:46:40 --> Severity: Notice --> Undefined offset: 73 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:46:40 --> Severity: Notice --> Undefined offset: 59 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 00:47:12 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 00:47:12 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 00:47:13 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 00:47:13 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 00:47:14 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 00:47:14 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 00:47:15 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-19 00:47:43 --> Severity: Notice --> Undefined offset: 59 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 00:47:43 --> Severity: Notice --> Undefined offset: 59 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:47:43 --> Severity: Notice --> Undefined offset: 60 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:47:43 --> Severity: Notice --> Undefined offset: 61 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:47:43 --> Severity: Notice --> Undefined offset: 62 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:47:43 --> Severity: Notice --> Undefined offset: 63 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:47:43 --> Severity: Notice --> Undefined offset: 64 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:47:43 --> Severity: Notice --> Undefined offset: 65 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:47:43 --> Severity: Notice --> Undefined offset: 66 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:47:43 --> Severity: Notice --> Undefined offset: 67 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:47:43 --> Severity: Notice --> Undefined offset: 68 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:47:43 --> Severity: Notice --> Undefined offset: 69 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:47:43 --> Severity: Notice --> Undefined offset: 70 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:47:43 --> Severity: Notice --> Undefined offset: 71 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:47:43 --> Severity: Notice --> Undefined offset: 72 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:47:43 --> Severity: Notice --> Undefined offset: 73 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:47:43 --> Severity: Notice --> Undefined offset: 59 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 00:48:59 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 00:48:59 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 00:48:59 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 00:48:59 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 00:49:00 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 00:49:00 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 00:49:01 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-19 00:49:25 --> Severity: Notice --> Undefined offset: 60 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:49:25 --> Severity: Notice --> Undefined offset: 61 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:49:25 --> Severity: Notice --> Undefined offset: 62 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:49:25 --> Severity: Notice --> Undefined offset: 63 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:49:25 --> Severity: Notice --> Undefined offset: 64 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:49:25 --> Severity: Notice --> Undefined offset: 65 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:49:25 --> Severity: Notice --> Undefined offset: 66 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:49:25 --> Severity: Notice --> Undefined offset: 67 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:49:25 --> Severity: Notice --> Undefined offset: 68 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:49:25 --> Severity: Notice --> Undefined offset: 69 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:49:25 --> Severity: Notice --> Undefined offset: 70 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:49:25 --> Severity: Notice --> Undefined offset: 71 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:49:25 --> Severity: Notice --> Undefined offset: 72 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:49:25 --> Severity: Notice --> Undefined offset: 73 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:50:55 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 00:50:55 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 00:50:56 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 00:50:56 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 00:50:57 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-19 00:51:24 --> Severity: Notice --> Undefined offset: 60 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:51:24 --> Severity: Notice --> Undefined offset: 61 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:51:24 --> Severity: Notice --> Undefined offset: 62 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:51:24 --> Severity: Notice --> Undefined offset: 63 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:51:24 --> Severity: Notice --> Undefined offset: 64 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:51:24 --> Severity: Notice --> Undefined offset: 65 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:51:24 --> Severity: Notice --> Undefined offset: 66 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:51:24 --> Severity: Notice --> Undefined offset: 67 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:51:24 --> Severity: Notice --> Undefined offset: 68 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:51:24 --> Severity: Notice --> Undefined offset: 69 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:51:24 --> Severity: Notice --> Undefined offset: 70 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:51:24 --> Severity: Notice --> Undefined offset: 71 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:51:24 --> Severity: Notice --> Undefined offset: 72 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:51:24 --> Severity: Notice --> Undefined offset: 73 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:51:24 --> Severity: Notice --> Undefined offset: 74 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:52:56 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 00:52:56 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 00:53:07 --> Severity: Notice --> Undefined offset: 60 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:53:07 --> Severity: Notice --> Undefined offset: 61 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:53:07 --> Severity: Notice --> Undefined offset: 62 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:53:07 --> Severity: Notice --> Undefined offset: 63 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:53:07 --> Severity: Notice --> Undefined offset: 64 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:53:07 --> Severity: Notice --> Undefined offset: 65 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:53:07 --> Severity: Notice --> Undefined offset: 66 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:53:07 --> Severity: Notice --> Undefined offset: 67 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:53:07 --> Severity: Notice --> Undefined offset: 68 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:53:07 --> Severity: Notice --> Undefined offset: 69 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:53:07 --> Severity: Notice --> Undefined offset: 70 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:53:07 --> Severity: Notice --> Undefined offset: 71 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:53:07 --> Severity: Notice --> Undefined offset: 72 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:53:07 --> Severity: Notice --> Undefined offset: 73 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:53:07 --> Severity: Notice --> Undefined offset: 74 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:53:07 --> Severity: Notice --> Undefined offset: 75 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:53:07 --> Severity: Notice --> Undefined offset: 76 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:53:07 --> Severity: Notice --> Undefined offset: 77 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:53:07 --> Severity: Notice --> Undefined offset: 78 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:54:31 --> Severity: Notice --> Undefined offset: 60 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:54:31 --> Severity: Notice --> Undefined offset: 61 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:54:31 --> Severity: Notice --> Undefined offset: 62 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:54:31 --> Severity: Notice --> Undefined offset: 63 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:54:31 --> Severity: Notice --> Undefined offset: 64 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:54:31 --> Severity: Notice --> Undefined offset: 65 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:54:31 --> Severity: Notice --> Undefined offset: 66 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:54:31 --> Severity: Notice --> Undefined offset: 67 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:54:31 --> Severity: Notice --> Undefined offset: 68 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 00:56:50 --> Severity: Notice --> Undefined offset: 60 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 01:00:51 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 01:00:51 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:01 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:02 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:02 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:02 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:02 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:02 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:02 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:02 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:02 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:02 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:02 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:02 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:02 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:02 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:02 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:02 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:02 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:02 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:03 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:04 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:06 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:08 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:08 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:08 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:08 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:08 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:08 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:08 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:08 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:08 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:08 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:08 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:08 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:08 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:08 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:08 --> Severity: Notice --> Array to string conversion /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 866
ERROR - 2015-07-19 01:03:09 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-19 14:58:35 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 14:58:35 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 14:58:38 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 14:58:38 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 14:58:40 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 14:58:40 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 14:58:43 --> Severity: Notice --> Undefined offset: 180 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 14:58:43 --> Severity: Notice --> Undefined offset: 181 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 14:58:43 --> Severity: Notice --> Undefined offset: 182 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 14:58:43 --> Severity: Notice --> Undefined offset: 183 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 14:58:43 --> Severity: Notice --> Undefined offset: 184 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 14:58:43 --> Severity: Notice --> Undefined offset: 185 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 14:58:43 --> Severity: Notice --> Undefined offset: 186 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 14:58:43 --> Severity: Notice --> Undefined offset: 187 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 14:58:43 --> Severity: Notice --> Undefined offset: 188 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 14:58:43 --> Severity: Notice --> Undefined offset: 189 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 14:58:43 --> Severity: Notice --> Undefined offset: 190 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 14:58:43 --> Severity: Notice --> Undefined offset: 191 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 14:58:43 --> Severity: Notice --> Undefined offset: 192 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:00:01 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 15:00:01 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 15:00:03 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 15:00:03 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 15:00:06 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 15:00:06 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 15:00:08 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-19 15:00:28 --> Severity: Notice --> Undefined offset: 180 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:00:28 --> Severity: Notice --> Undefined offset: 181 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:00:28 --> Severity: Notice --> Undefined offset: 182 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:00:28 --> Severity: Notice --> Undefined offset: 183 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:00:28 --> Severity: Notice --> Undefined offset: 184 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:00:28 --> Severity: Notice --> Undefined offset: 185 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:00:28 --> Severity: Notice --> Undefined offset: 186 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:00:28 --> Severity: Notice --> Undefined offset: 187 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:00:28 --> Severity: Notice --> Undefined offset: 188 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:00:28 --> Severity: Notice --> Undefined offset: 189 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:00:28 --> Severity: Notice --> Undefined offset: 190 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:00:28 --> Severity: Notice --> Undefined offset: 191 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:00:28 --> Severity: Notice --> Undefined offset: 192 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:05:38 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 15:05:38 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 15:05:40 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 15:05:40 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 15:05:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-19 15:25:30 --> Severity: Notice --> Undefined offset: 180 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:25:30 --> Severity: Notice --> Undefined offset: 181 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:25:30 --> Severity: Notice --> Undefined offset: 182 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:25:30 --> Severity: Notice --> Undefined offset: 183 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:25:30 --> Severity: Notice --> Undefined offset: 184 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:25:30 --> Severity: Notice --> Undefined offset: 185 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:25:30 --> Severity: Notice --> Undefined offset: 186 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:25:30 --> Severity: Notice --> Undefined offset: 187 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:25:30 --> Severity: Notice --> Undefined offset: 188 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:25:30 --> Severity: Notice --> Undefined offset: 189 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:27:39 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 15:27:39 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 15:27:42 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 15:27:42 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 15:27:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-19 15:44:24 --> Severity: Notice --> Undefined offset: 180 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:44:24 --> Severity: Notice --> Undefined offset: 181 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:44:24 --> Severity: Notice --> Undefined offset: 182 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:44:24 --> Severity: Notice --> Undefined offset: 183 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:44:24 --> Severity: Notice --> Undefined offset: 184 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:44:24 --> Severity: Notice --> Undefined offset: 185 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:44:24 --> Severity: Notice --> Undefined offset: 186 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:44:24 --> Severity: Notice --> Undefined offset: 187 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:44:24 --> Severity: Notice --> Undefined offset: 188 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:44:24 --> Severity: Notice --> Undefined offset: 189 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:45:28 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 15:45:28 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 15:45:42 --> Severity: Notice --> Undefined offset: 180 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:45:42 --> Severity: Notice --> Undefined offset: 181 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:45:42 --> Severity: Notice --> Undefined offset: 182 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:45:42 --> Severity: Notice --> Undefined offset: 183 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:45:42 --> Severity: Notice --> Undefined offset: 184 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:45:42 --> Severity: Notice --> Undefined offset: 185 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:47:44 --> Severity: Notice --> Undefined offset: 180 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:47:44 --> Severity: Notice --> Undefined offset: 181 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:47:44 --> Severity: Notice --> Undefined offset: 182 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:47:44 --> Severity: Notice --> Undefined offset: 183 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:47:44 --> Severity: Notice --> Undefined offset: 184 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:47:44 --> Severity: Notice --> Undefined offset: 185 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:47:44 --> Severity: Notice --> Undefined offset: 186 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:47:44 --> Severity: Notice --> Undefined offset: 187 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:47:44 --> Severity: Notice --> Undefined offset: 188 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:47:44 --> Severity: Notice --> Undefined offset: 189 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:47:44 --> Severity: Notice --> Undefined offset: 190 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:47:44 --> Severity: Notice --> Undefined offset: 191 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:47:44 --> Severity: Notice --> Undefined offset: 192 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:52:32 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 15:52:32 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 15:52:33 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 15:52:33 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 15:52:34 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 15:52:34 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 15:52:35 --> Severity: Notice --> Undefined offset: 55 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:52:35 --> Severity: Notice --> Undefined offset: 56 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:52:35 --> Severity: Notice --> Undefined offset: 57 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:52:35 --> Severity: Notice --> Undefined offset: 58 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:52:35 --> Severity: Notice --> Undefined offset: 59 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:52:35 --> Severity: Notice --> Undefined offset: 60 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:52:35 --> Severity: Notice --> Undefined offset: 61 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:52:35 --> Severity: Notice --> Undefined offset: 62 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:52:35 --> Severity: Notice --> Undefined offset: 63 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:52:35 --> Severity: Notice --> Undefined offset: 64 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:55:17 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 15:55:18 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 15:56:39 --> Severity: Notice --> Undefined offset: 55 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:56:39 --> Severity: Notice --> Undefined offset: 56 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:56:39 --> Severity: Notice --> Undefined offset: 57 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:56:39 --> Severity: Notice --> Undefined offset: 58 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:56:39 --> Severity: Notice --> Undefined offset: 59 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:56:39 --> Severity: Notice --> Undefined offset: 60 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:56:39 --> Severity: Notice --> Undefined offset: 61 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:56:39 --> Severity: Notice --> Undefined offset: 62 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:58:26 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 15:58:26 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 15:58:27 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 15:58:27 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 15:58:28 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 15:58:28 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 15:58:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-19 15:58:47 --> Severity: Notice --> Undefined offset: 55 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 15:58:47 --> Severity: Notice --> Undefined offset: 55 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:58:47 --> Severity: Notice --> Undefined offset: 56 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:58:47 --> Severity: Notice --> Undefined offset: 57 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:58:47 --> Severity: Notice --> Undefined offset: 58 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:58:47 --> Severity: Notice --> Undefined offset: 59 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:58:47 --> Severity: Notice --> Undefined offset: 60 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:58:47 --> Severity: Notice --> Undefined offset: 61 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:58:47 --> Severity: Notice --> Undefined offset: 62 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:58:47 --> Severity: Notice --> Undefined offset: 63 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:58:47 --> Severity: Notice --> Undefined offset: 64 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 15:58:47 --> Severity: Notice --> Undefined offset: 55 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 16:01:01 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 16:01:01 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 16:01:02 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 16:01:02 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 16:01:03 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-19 16:01:56 --> Severity: Notice --> Undefined offset: 55 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 16:01:56 --> Severity: Notice --> Undefined offset: 55 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 16:01:56 --> Severity: Notice --> Undefined offset: 55 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 16:25:35 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 16:25:35 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 16:25:36 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 16:25:36 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 16:25:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-19 16:25:55 --> Severity: Notice --> Undefined offset: 40 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 16:25:55 --> Severity: Notice --> Undefined offset: 40 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 16:25:55 --> Severity: Notice --> Undefined offset: 40 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 16:27:31 --> Severity: Notice --> Undefined offset: 41 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 16:27:31 --> Severity: Notice --> Undefined offset: 42 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 16:27:31 --> Severity: Notice --> Undefined offset: 43 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 16:27:31 --> Severity: Notice --> Undefined offset: 44 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 16:33:00 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 16:33:00 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 16:33:00 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 16:33:00 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 16:33:01 --> Severity: Notice --> Undefined offset: 36 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 16:33:01 --> Severity: Notice --> Undefined offset: 36 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 16:33:01 --> Severity: Notice --> Undefined offset: 36 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 16:38:47 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 16:38:47 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 16:38:48 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 16:38:48 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 16:38:49 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 16:38:49 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 16:38:49 --> Severity: Notice --> Undefined offset: 50 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 16:38:49 --> Severity: Notice --> Undefined offset: 50 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 16:38:49 --> Severity: Notice --> Undefined offset: 50 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 20:23:53 --> Severity: Notice --> Undefined offset: 37 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:23:53 --> Severity: Notice --> Undefined offset: 38 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:23:53 --> Severity: Notice --> Undefined offset: 39 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:23:53 --> Severity: Notice --> Undefined offset: 40 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:23:53 --> Severity: Notice --> Undefined offset: 41 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:23:53 --> Severity: Notice --> Undefined offset: 42 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:23:53 --> Severity: Notice --> Undefined offset: 43 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:23:53 --> Severity: Notice --> Undefined offset: 44 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:23:53 --> Severity: Notice --> Undefined offset: 45 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:23:53 --> Severity: Notice --> Undefined offset: 46 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:23:53 --> Severity: Notice --> Undefined offset: 47 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:23:53 --> Severity: Notice --> Undefined offset: 48 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:33:07 --> Severity: Notice --> Undefined offset: 86 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:33:07 --> Severity: Notice --> Undefined offset: 87 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:33:07 --> Severity: Notice --> Undefined offset: 88 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:33:07 --> Severity: Notice --> Undefined offset: 89 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:33:07 --> Severity: Notice --> Undefined offset: 90 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:33:07 --> Severity: Notice --> Undefined offset: 91 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:33:07 --> Severity: Notice --> Undefined offset: 92 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:33:07 --> Severity: Notice --> Undefined offset: 93 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:33:07 --> Severity: Notice --> Undefined offset: 94 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:33:07 --> Severity: Notice --> Undefined offset: 95 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 86 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 87 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 88 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 89 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 90 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 91 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 92 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 93 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 94 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 95 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 96 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 97 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 98 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 99 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 100 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 101 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 102 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 103 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 104 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 105 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 106 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 107 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 108 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 109 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 110 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 111 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 112 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 113 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 114 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 115 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 116 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 117 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 118 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 119 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 120 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 121 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 122 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 123 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 124 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 125 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 126 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 127 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 128 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 129 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 130 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 131 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 132 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 133 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 134 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 135 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 136 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 137 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 138 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:35:24 --> Severity: Notice --> Undefined offset: 139 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:35 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 20:36:35 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 20:36:36 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 20:36:36 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 20:36:38 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 20:36:38 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 20:36:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 86 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 86 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 87 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 88 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 89 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 90 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 91 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 92 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 93 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 94 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 95 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 96 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 97 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 98 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 99 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 100 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 101 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 102 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 103 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 104 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 105 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 106 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 107 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 108 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 109 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 110 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 111 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 112 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 113 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 114 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 115 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:36:57 --> Severity: Notice --> Undefined offset: 86 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 20:38:23 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 20:38:23 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 20:38:24 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 20:38:24 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 20:38:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-19 20:39:17 --> Severity: Notice --> Undefined offset: 86 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 20:39:17 --> Severity: Notice --> Undefined offset: 86 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:39:17 --> Severity: Notice --> Undefined offset: 86 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 20:40:59 --> Severity: Notice --> Undefined offset: 87 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:40:59 --> Severity: Notice --> Undefined offset: 88 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 20:40:59 --> Severity: Notice --> Undefined offset: 89 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:09:19 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 21:09:19 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 21:09:20 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 21:09:20 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 21:09:21 --> Severity: Notice --> Undefined offset: 55 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 21:09:21 --> Severity: Notice --> Undefined offset: 56 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 21:09:21 --> Severity: Notice --> Undefined offset: 55 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:09:21 --> Severity: Notice --> Undefined offset: 56 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:09:21 --> Severity: Notice --> Undefined offset: 57 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:09:21 --> Severity: Notice --> Undefined offset: 58 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:09:21 --> Severity: Notice --> Undefined offset: 59 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:09:21 --> Severity: Notice --> Undefined offset: 60 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:09:21 --> Severity: Notice --> Undefined offset: 61 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:09:21 --> Severity: Notice --> Undefined offset: 62 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:09:21 --> Severity: Notice --> Undefined offset: 55 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 21:09:21 --> Severity: Notice --> Undefined offset: 56 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 56 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 56 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 57 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 58 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 59 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 60 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 61 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 62 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 63 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 64 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 65 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 66 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 67 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 68 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 69 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 70 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 71 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 72 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 73 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 74 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:11:00 --> Severity: Notice --> Undefined offset: 56 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 21:12:25 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 21:12:25 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 21:12:26 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 21:12:26 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 21:12:27 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 21:12:27 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 21:12:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-19 21:12:49 --> Severity: Notice --> Undefined offset: 56 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 21:12:49 --> Severity: Notice --> Undefined offset: 57 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 21:12:49 --> Severity: Notice --> Undefined offset: 56 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:12:49 --> Severity: Notice --> Undefined offset: 57 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:12:49 --> Severity: Notice --> Undefined offset: 58 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:12:49 --> Severity: Notice --> Undefined offset: 56 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 21:12:49 --> Severity: Notice --> Undefined offset: 57 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 21:14:32 --> Severity: Notice --> Undefined offset: 57 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 21:14:32 --> Severity: Notice --> Undefined offset: 57 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:14:32 --> Severity: Notice --> Undefined offset: 57 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 21:21:29 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 21:21:29 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 21:21:30 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 21:21:30 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 21:21:32 --> Severity: Notice --> Undefined offset: 65 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 21:21:32 --> Severity: Notice --> Undefined offset: 65 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 21:21:32 --> Severity: Notice --> Undefined offset: 65 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 22:03:01 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 22:03:01 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 121 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 122 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 123 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 121 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 122 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 123 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 124 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 125 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 126 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 127 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 128 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 129 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 130 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 131 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 132 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 133 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 134 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 135 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 136 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 137 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 138 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 139 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 140 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 141 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 142 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 143 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 144 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 145 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 146 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 147 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 148 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 149 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 150 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 151 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 152 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 153 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 154 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 155 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 156 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 157 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 158 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 159 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 160 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 161 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 162 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 163 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 164 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 165 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 166 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 167 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 168 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 169 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 170 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 171 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 172 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 173 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 174 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 175 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 176 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 177 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 178 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 179 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 180 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 181 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 182 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 183 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 184 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 185 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 186 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 121 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 122 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 22:03:03 --> Severity: Notice --> Undefined offset: 123 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 22:17:32 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 22:17:32 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 22:17:34 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 22:17:34 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 22:17:36 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 22:17:36 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 22:17:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 122 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 123 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 124 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 122 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 123 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 124 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 125 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 126 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 127 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 128 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 129 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 130 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 131 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 132 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 133 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 134 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 135 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 136 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 137 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 138 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 139 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 140 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 141 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 142 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 143 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 144 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 145 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 146 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 147 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 148 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 149 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 150 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 151 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 152 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 153 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 154 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 155 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 156 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 157 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 158 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 159 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 160 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 161 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 162 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 163 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 164 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 165 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 166 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 167 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 168 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 169 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 170 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 171 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 172 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 122 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 123 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 22:19:09 --> Severity: Notice --> Undefined offset: 124 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 22:38:34 --> Severity: Notice --> Undefined offset: 123 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 22:38:34 --> Severity: Notice --> Undefined offset: 124 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 22:38:34 --> Severity: Notice --> Undefined offset: 123 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:38:34 --> Severity: Notice --> Undefined offset: 124 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:38:34 --> Severity: Notice --> Undefined offset: 125 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:38:34 --> Severity: Notice --> Undefined offset: 126 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:38:34 --> Severity: Notice --> Undefined offset: 127 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:38:34 --> Severity: Notice --> Undefined offset: 128 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:38:34 --> Severity: Notice --> Undefined offset: 129 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:38:34 --> Severity: Notice --> Undefined offset: 130 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 22:38:34 --> Severity: Notice --> Undefined offset: 123 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 22:38:34 --> Severity: Notice --> Undefined offset: 124 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 22:40:14 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 22:40:14 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 22:40:16 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 22:40:16 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 22:40:18 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-19 23:08:40 --> Severity: Notice --> Undefined offset: 124 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 23:08:40 --> Severity: Notice --> Undefined offset: 125 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 23:08:40 --> Severity: Notice --> Undefined offset: 124 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:08:40 --> Severity: Notice --> Undefined offset: 125 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:08:40 --> Severity: Notice --> Undefined offset: 126 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:08:40 --> Severity: Notice --> Undefined offset: 127 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:08:40 --> Severity: Notice --> Undefined offset: 128 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:08:40 --> Severity: Notice --> Undefined offset: 129 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:08:40 --> Severity: Notice --> Undefined offset: 130 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:08:40 --> Severity: Notice --> Undefined offset: 131 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:08:40 --> Severity: Notice --> Undefined offset: 132 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:08:40 --> Severity: Notice --> Undefined offset: 133 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:08:40 --> Severity: Notice --> Undefined offset: 124 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 23:08:40 --> Severity: Notice --> Undefined offset: 125 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 125 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 125 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 126 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 127 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 128 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 129 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 130 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 131 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 132 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 133 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 134 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 135 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 136 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 137 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 138 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 139 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 140 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 141 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 142 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 143 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 144 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 145 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 146 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 147 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 148 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 149 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 150 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 151 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 152 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 153 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 154 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 155 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 156 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 157 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 158 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 159 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 160 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 161 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 162 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 163 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 164 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 165 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 166 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 167 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 168 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 169 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 170 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:13:35 --> Severity: Notice --> Undefined offset: 125 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 23:15:21 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 23:15:21 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 23:15:23 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 23:15:23 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 23:15:25 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 23:15:25 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 23:15:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 125 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 126 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 125 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 126 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 127 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 128 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 129 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 130 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 131 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 132 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 133 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 134 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 135 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 136 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 137 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 138 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 139 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 140 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 141 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 142 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 143 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:49 --> Severity: Notice --> Undefined offset: 144 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:16:50 --> Severity: Notice --> Undefined offset: 125 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 23:16:50 --> Severity: Notice --> Undefined offset: 126 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 23:19:31 --> Severity: Notice --> Undefined offset: 126 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 23:19:31 --> Severity: Notice --> Undefined offset: 126 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:19:31 --> Severity: Notice --> Undefined offset: 127 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:19:31 --> Severity: Notice --> Undefined offset: 128 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:19:31 --> Severity: Notice --> Undefined offset: 129 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:19:31 --> Severity: Notice --> Undefined offset: 130 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:19:31 --> Severity: Notice --> Undefined offset: 131 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:19:31 --> Severity: Notice --> Undefined offset: 126 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 23:21:22 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 23:21:22 --> Severity: Notice --> Undefined offset: 1 /var/www/html/registridev/modules/mara2/controllers/mara2.php 1693
ERROR - 2015-07-19 23:21:23 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 23:21:23 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 23:21:25 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 23:21:25 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 23:21:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 127 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 127 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 128 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 129 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 130 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 131 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 132 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 133 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 134 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 135 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 136 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 137 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 138 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 139 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 140 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 141 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 142 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 143 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 144 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 145 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:22:44 --> Severity: Notice --> Undefined offset: 127 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
ERROR - 2015-07-19 23:24:18 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 589
ERROR - 2015-07-19 23:24:18 --> Severity: Notice --> Undefined offset: 2 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 513
ERROR - 2015-07-19 23:24:19 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 868
ERROR - 2015-07-19 23:24:20 --> Severity: Notice --> Undefined offset: 3 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 835
ERROR - 2015-07-19 23:24:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at /var/www/html/registridev/system/core/Exceptions.php:211) /var/www/html/registridev/system/helpers/url_helper.php 547
ERROR - 2015-07-19 23:26:46 --> Severity: Notice --> Undefined offset: 127 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 469
ERROR - 2015-07-19 23:26:46 --> Severity: Notice --> Undefined offset: 127 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 703
ERROR - 2015-07-19 23:26:46 --> Severity: Notice --> Undefined offset: 127 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 1024
