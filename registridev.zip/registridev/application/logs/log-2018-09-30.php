<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-09-30 20:21:15 --> 404 Page Not Found: mara2/step2b
ERROR - 2018-09-30 20:21:36 --> 404 Page Not Found: mara2/step2b
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 42 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 43 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 44 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 45 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 46 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 47 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 48 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 49 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 50 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 51 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 52 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 53 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 54 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 55 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 56 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 57 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 58 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 59 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 60 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 61 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 62 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 63 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 64 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 65 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 66 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 67 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 68 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 69 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 70 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 71 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 72 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 73 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 74 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 75 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 76 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 77 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
ERROR - 2018-09-30 20:45:22 --> Severity: Notice --> Undefined offset: 78 /var/www/html/registridev/modules/mara2/controllers/maraAPI.php 706
