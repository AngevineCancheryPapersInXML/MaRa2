<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-03-11 15:41:49 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 15:41:49 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 15:42:40 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 15:43:30 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 15:44:20 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 15:45:10 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 15:46:00 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 16:26:55 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 16:26:56 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 16:27:47 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 16:28:37 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 16:29:27 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 16:31:57 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 16:32:47 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 23:03:57 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 23:03:57 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 23:04:48 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 23:05:38 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 23:06:28 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 23:07:18 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
ERROR - 2018-03-11 23:09:48 --> Severity: Core Warning --> Module 'mcrypt' already loaded Unknown 0
