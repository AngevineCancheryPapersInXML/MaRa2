<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-10-01 10:38:41 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1724
ERROR - 2018-10-01 10:38:58 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1724
ERROR - 2018-10-01 10:39:12 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1724
ERROR - 2018-10-01 10:41:14 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1769
ERROR - 2018-10-01 10:41:14 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1769
ERROR - 2018-10-01 10:41:14 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1769
ERROR - 2018-10-01 10:41:14 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1769
ERROR - 2018-10-01 10:41:14 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1769
ERROR - 2018-10-01 10:41:14 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1794
ERROR - 2018-10-01 10:41:14 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1794
ERROR - 2018-10-01 10:41:14 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1794
ERROR - 2018-10-01 10:41:14 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1794
ERROR - 2018-10-01 10:41:14 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1794
ERROR - 2018-10-01 10:41:15 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1769
ERROR - 2018-10-01 10:41:15 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1769
ERROR - 2018-10-01 10:41:15 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1769
ERROR - 2018-10-01 10:41:15 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1769
ERROR - 2018-10-01 10:41:15 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1769
ERROR - 2018-10-01 10:41:15 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1794
ERROR - 2018-10-01 10:41:15 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1794
ERROR - 2018-10-01 10:41:15 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1794
ERROR - 2018-10-01 10:41:15 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1794
ERROR - 2018-10-01 10:41:15 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1794
ERROR - 2018-10-01 10:41:26 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1724
ERROR - 2018-10-01 10:45:16 --> Severity: Warning --> DOMDocument::schemaValidate(): Invalid Schema /var/www/html/registridev/modules/mara2/controllers/mara2.php 1724
ERROR - 2018-10-01 23:14:46 --> 404 Page Not Found: 
ERROR - 2018-10-01 23:15:56 --> Severity: Warning --> chmod(): Operation not permitted /var/www/html/registridev/modules/registri/controllers/install.php 240
ERROR - 2018-10-01 23:23:59 --> Severity: Warning --> chmod(): Operation not permitted /var/www/html/registridev/modules/mara/controllers/install.php 162
