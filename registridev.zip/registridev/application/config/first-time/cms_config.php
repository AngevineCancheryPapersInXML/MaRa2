<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

$config['cms_table_prefix'] = '';
$config['max_menu_depth'] = 10;
