In CodeIgniter 3.0, the class name should be ucfirst, while in CodeIgniter 2.1.x and below, the classname should be lcase<br />
No-CMS support both, CodeIgniter 3.0 and CodeIgniter 2.1.x convention.