<?php
class grocery_crud_model_mysqli extends grocery_CRUD_Generic_Model{

}
