<?php
class grocery_crud_model_sqlite3 extends grocery_CRUD_Generic_Model{

}
