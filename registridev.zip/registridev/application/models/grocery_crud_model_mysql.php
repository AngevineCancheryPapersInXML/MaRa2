<?php
class grocery_crud_model_mysql extends grocery_CRUD_Generic_Model{

}
